GreenLemon 1v1 Oda - Cam kapılı 1v1 odaları
Hedef: Paper 1.20.1 (Java 17+)  |  Bağımlılık: yok

JAR NASIL OLUR? (3 yoldan biri)
1) JDK 17 + Maven: bu klasörde  mvn package  -> target/GreenLemon-1v1Oda-1.0.0.jar -> plugins/
2) GitHub: klasörü (private) repoya yükle, Actions otomatik derler (.github/workflows/build.yml hazır).
3) IntelliJ IDEA: pom.xml'i Maven projesi olarak aç, Maven > package.

ODA KURULUMU (yetkili, greenlemon.oda.admin)
 1) /1v1 balta                 -> altın "1v1 Oda Seçim Baltası" gelir
 2) Baltayla odanın bir köşesine SOL tık, karşı köşesine (yüksekliği de kapsayacak şekilde) SAĞ tık
 3) /1v1 olustur <isim>        -> oda oluşur
 4) Oda içinde 1. oyuncunun duracağı yerde  /1v1 spawn1 <isim>   (baktığın yön de kaydedilir)
 5) Oda içinde 2. oyuncunun duracağı yerde  /1v1 spawn2 <isim>
 6) Kapının DIŞINDA, çıkınca gelinecek yerde /1v1 dis <isim>
 7) Kapı camına bakıp (en fazla 6 blok)      /1v1 kapiekle <isim>   (birden fazla cam eklenebilir)
 8) (isteğe bağlı) Süre dolunca gidilecek sunucu spawn'ı: /1v1 spawnayarla
 /1v1 bilgi <isim> ile eksik var mı kontrol et. Eksik oda oyuncuya "hazır değil" der.

OYUN AKIŞI
 - Oyuncu kapı camına DOKUNUR (sol/sağ tık). Yaklaşmak yetmez, sadece dokunmak girer.
 - İlk giren spawn1'e ışınlanır ve rakip bekler (boss bar). Çıkmak için tekrar cama dokunur.
 - İkinci oyuncu cama dokununca spawn2'ye ışınlanır; 5 sn geri sayım (donma), sonra dövüş başlar.
 - Dövüş süresi 8 dk (boss bar). Dolunca berabere: ikisi de sunucu spawn'ına ışınlanır, oda yenilenir.
 - Biri ölünce: kazanan 30 sn odada kalır (eşyaları toplar). Bu sürede oda KİLİTLİ, kimse giremez.
   Kazanan istediği an cama dokunarak çıkabilir ya da /spawn /hub /warp çekebilir (engel kalkar).
   30 sn dolunca kazanan hâlâ içerideyse spawn'a ışınlanır, yerdeki eşyalar temizlenir, oda açılır.
 - Maç sırasında (bekleme, geri sayım, dövüş) /spawn /hub /warp /home /tpa ... ÇALIŞMAZ ve cam kapıdan çıkılamaz.
 - Biri oyundan çıkarsa: dövüşteyse rakip kazanır; geri sayımdaysa rakip tekrar bekleme moduna döner.
 - Ölen oyuncu ölüm ekranı olmadan spawn'a döner.

EKSTRALAR
 - /1v1 (menü): odaların canlı durumu (boş/bekliyor/dolu), kalan süre, oyuncular, eşya düşme ve süre bilgisi
 - ODA BAZLI AYAR: /1v1 esya <oda> ac|kapat|varsayilan  (ölenin eşyaları düşsün mü)
                   /1v1 sure <oda> <1-60|varsayilan>   (oda maç süresi, dakika)
 - Kapı camı rengi: YEŞİL = boş, SARI = rakip bekleniyor, KIRMIZI = dolu/kilitli (config: kapi-renk)
 - Boss bar: bekleme / geri sayım / kalan süre / oda yenilenme süresi
 - Maçta ender pearl, chorus ve /tp ile kaçış engeli; oda sınırından çıkan geri ışınlanır
 - Odalarda yetkisizler blok kıramaz/koyamaz; PvP sadece rakipler arasında ve sadece dövüş fazında
 - Odada kapanan oyuncu tekrar girince spawn'a gider; tek başına bekleyen 5 dk sonra çıkarılır
 - /1v1 istatistik [oyuncu]  ve  /1v1 top (kazanma/kayıp/beraberlik)
 - Kazanan tüm sunucuya duyurulur (kapatılabilir)
 - Komut engeli KARA_LISTE veya BEYAZ_LISTE modunda; takma adlar da yakalanır

KOMUTLAR
 Oyuncu: /1v1 istatistik [oyuncu], /1v1 top, /1v1 yardim   
 Yetkili: /1v1 balta | esya | sure | olustur | sil | bolge | spawn1 | spawn2 | dis | kapiekle | kapisil | liste | bilgi | sifirla | spawnayarla | reload
İzinler: greenlemon.oda.kullan (varsayılan herkes), .admin (op), .bypass (oda içinde komut engelini yok sayar)

AYARLAR (config.yml): geri sayım, 8 dk maç süresi, 30 sn bitiş bekleme, envanter koruma (ölenin eşyaları düşsün mü),
 komut listesi, sesler ve tüm mesajlar. Veriler: odalar.yml, stats.yml

DÜRÜST NOTLAR
 - Derlenip canlı sunucuda test edilmedi. Önce test sunucusunda iki hesapla dene (özellikle: kapıya dokunma,
   geri sayım, ölüm/respawn, 30 sn kilidi, süre dolması, çıkış yapma).
 - /spawn /hub /warp'ı engellemek için komut adına bakılır. Başka bir eklenti ışınlamayı komut dışı yoldan
   yapıyorsa (menü, NPC) engellenmez; gerekirse o eklentide 1v1 odasını yasakla.
 - Envanter koruma kapalıyken (varsayılan) ölenin eşyaları kazanana kalır; 30 sn sonunda yerde kalanlar silinir.
   İstemiyorsan config'te mac.envanter-koru: true yap.
 - Cam rengi değişimi sadece cam/cam paneller için çalışır; başka blok eklersen renk değişmez ama giriş çalışır.
 - Başka bir eklenti (WorldGuard vb.) aynı bölgede etkileşimi iptal ederse kapı dokunuşu için öncelik en yüksek
   ayarlanmıştır, yine de sorun olursa bana yaz.
