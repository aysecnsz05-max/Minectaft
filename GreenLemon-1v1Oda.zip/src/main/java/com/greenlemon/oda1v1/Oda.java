package com.greenlemon.oda1v1;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.boss.BossBar;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Bir 1v1 odası: kalıcı veri (bölge, noktalar, kapılar) + çalışma durumu. */
final class Oda {
    enum Durum { ACIK, BEKLEME, GERI_SAYIM, MAC, BITIS }

    record Konum(String dunya, double x, double y, double z, float yaw, float pitch) {
        static Konum of(Location l) {
            return new Konum(l.getWorld().getName(), l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch());
        }

        /** Dünya yüklü değilse null. */
        Location al() {
            World w = Bukkit.getWorld(dunya);
            return w == null ? null : new Location(w, x, y, z, yaw, pitch);
        }

        String yazi() {
            return String.format("%.1f, %.1f, %.1f", x, y, z);
        }
    }

    static final class Kapi {
        final int x;
        final int y;
        final int z;
        final String orijinal;

        Kapi(int x, int y, int z, String orijinal) {
            this.x = x;
            this.y = y;
            this.z = z;
            this.orijinal = orijinal;
        }

        boolean cam() {
            return orijinal.contains("GLASS");
        }

        boolean panel() {
            return orijinal.contains("PANE");
        }
    }

    // ---- Kalıcı veri ----
    final String ad;
    String dunya = "";
    int minX, minY, minZ, maxX, maxY, maxZ;
    boolean bolgeVar;
    Konum spawn1;
    Konum spawn2;
    Konum dis;
    /** null = config varsayılanı */
    Boolean esyaDusme;
    /** null = config varsayılanı */
    Integer macDakika;
    final List<Kapi> kapilar = new ArrayList<>();

    // ---- Çalışma durumu ----
    Durum durum = Durum.ACIK;
    UUID p1;
    UUID p2;
    UUID kazanan;
    BossBar bar;
    int geriSayim;
    long beklemeBasi;
    long macBitis;
    long bitisBitis;
    final Set<Integer> uyarilar = new HashSet<>();

    Oda(String ad) {
        this.ad = ad;
    }

    void bolgeAyarla(String dunya, Location a, Location b) {
        this.dunya = dunya;
        minX = Math.min(a.getBlockX(), b.getBlockX());
        minY = Math.min(a.getBlockY(), b.getBlockY());
        minZ = Math.min(a.getBlockZ(), b.getBlockZ());
        maxX = Math.max(a.getBlockX(), b.getBlockX());
        maxY = Math.max(a.getBlockY(), b.getBlockY());
        maxZ = Math.max(a.getBlockZ(), b.getBlockZ());
        bolgeVar = true;
    }

    boolean bolgedeMi(Location l) {
        if (!bolgeVar || l.getWorld() == null || !l.getWorld().getName().equals(dunya)) return false;
        int x = l.getBlockX();
        int y = l.getBlockY();
        int z = l.getBlockZ();
        return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
    }

    List<String> eksikler() {
        List<String> e = new ArrayList<>();
        if (!bolgeVar) e.add("bölge");
        if (spawn1 == null) e.add("spawn1");
        if (spawn2 == null) e.add("spawn2");
        if (dis == null) e.add("dis");
        if (kapilar.isEmpty()) e.add("kapı camı");
        return e;
    }

    boolean hazirMi() {
        return eksikler().isEmpty();
    }

    Konum spawnOf(UUID u) {
        if (u == null) return null;
        if (u.equals(p1)) return spawn1;
        if (u.equals(p2)) return spawn2;
        return null;
    }

    UUID rakip(UUID u) {
        if (u == null) return null;
        if (u.equals(p1)) return p2;
        if (u.equals(p2)) return p1;
        return null;
    }
}
