package com.greenlemon.oda1v1;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.command.PluginCommand;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class OdaPlugin extends JavaPlugin {

    /** Admin'in balta ile seçtiği iki köşe. */
    static final class Secim {
        Location a;
        Location b;
    }

    private Odalar odalar;
    private Istatistik istatistik;
    private Yonetici yonetici;
    private NamespacedKey baltaAnahtar;
    private final Map<UUID, Secim> secimler = new HashMap<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        baltaAnahtar = new NamespacedKey(this, "oda_balta");
        odalar = new Odalar(this);
        odalar.yukle();
        istatistik = new Istatistik(this);
        istatistik.yukle();
        yonetici = new Yonetici(this);

        getServer().getPluginManager().registerEvents(new Dinleyici(this), this);
        Komutlar komutlar = new Komutlar(this);
        PluginCommand c = getCommand("1v1");
        if (c != null) {
            c.setExecutor(komutlar);
            c.setTabCompleter(komutlar);
        }
        yonetici.tumKapilariBoya();
        yonetici.baslat();
        getLogger().info(odalar.tum().size() + " 1v1 odası yüklendi.");
    }

    @Override
    public void onDisable() {
        if (yonetici != null) yonetici.kapat();
        if (odalar != null) odalar.kaydet();
        if (istatistik != null) istatistik.kaydet();
    }

    void yenidenYukle() {
        reloadConfig();
        yonetici.tumOdalariSifirla();
        odalar.yukle();
        yonetici.tumKapilariBoya();
    }

    Odalar odalar() {
        return odalar;
    }

    Istatistik istatistik() {
        return istatistik;
    }

    Yonetici yonetici() {
        return yonetici;
    }

    Map<UUID, Secim> secimler() {
        return secimler;
    }

    // ---------------- Balta ----------------

    ItemStack baltaOlustur() {
        ItemStack item = new ItemStack(Material.GOLDEN_AXE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(Yazi.renk(getConfig().getString("balta.isim", "&6&l1v1 Oda Seçim Baltası")));
        List<String> lore = new ArrayList<>();
        for (String s : getConfig().getStringList("balta.aciklama")) lore.add(Yazi.renk(s));
        meta.setLore(lore);
        meta.setUnbreakable(true);
        meta.addEnchant(Enchantment.DURABILITY, 1, true);
        meta.addItemFlags(ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_UNBREAKABLE, ItemFlag.HIDE_ATTRIBUTES);
        meta.getPersistentDataContainer().set(baltaAnahtar, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    boolean baltaMi(ItemStack item) {
        if (item == null || item.getType() != Material.GOLDEN_AXE || !item.hasItemMeta()) return false;
        Byte b = item.getItemMeta().getPersistentDataContainer().get(baltaAnahtar, PersistentDataType.BYTE);
        return b != null && b == 1;
    }

    // ---------------- Yardımcılar ----------------

    /** Süre bitince / berabere kalınca gidilecek yer. */
    Location sunucuSpawn() {
        if (odalar.sunucuSpawn != null) {
            Location l = odalar.sunucuSpawn.al();
            if (l != null) return l;
        }
        return Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    String m(String anahtar, String... cift) {
        String t = getConfig().getString("mesajlar." + anahtar, "&cMesaj bulunamadı: " + anahtar);
        return Yazi.renk(doldur(t, cift));
    }

    List<String> mListe(String anahtar) {
        List<String> sonuc = new ArrayList<>();
        for (String t : getConfig().getStringList("mesajlar." + anahtar)) sonuc.add(Yazi.renk(doldur(t)));
        return sonuc;
    }

    private String doldur(String t, String... cift) {
        t = t.replace("{prefix}", getConfig().getString("mesajlar.prefix", ""));
        for (int i = 0; i + 1 < cift.length; i += 2) t = t.replace(cift[i], cift[i + 1]);
        return t;
    }

    void ses(Player p, String anahtar, float perde) {
        try {
            Sound s = Sound.valueOf(getConfig().getString("sesler." + anahtar, "").toUpperCase(Locale.ROOT));
            p.playSound(p.getLocation(), s, 1.0f, perde);
        } catch (IllegalArgumentException ignored) {
            // ses adı geçersiz veya boş
        }
    }
}
