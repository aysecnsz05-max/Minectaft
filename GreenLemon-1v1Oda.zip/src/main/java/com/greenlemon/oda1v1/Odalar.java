package com.greenlemon.oda1v1;

import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Odaların depolanması (odalar.yml) ve aranması. Ana thread. */
final class Odalar {
    private final OdaPlugin plugin;
    private final File dosya;
    private final Map<String, Oda> odalar = new LinkedHashMap<>();
    private final Map<String, Oda> kapiIndeks = new HashMap<>();
    Oda.Konum sunucuSpawn;

    Odalar(OdaPlugin plugin) {
        this.plugin = plugin;
        this.dosya = new File(plugin.getDataFolder(), "odalar.yml");
    }

    Collection<Oda> tum() {
        return new ArrayList<>(odalar.values());
    }

    Oda al(String ad) {
        return ad == null ? null : odalar.get(ad.toLowerCase(Locale.ROOT));
    }

    void ekle(Oda o) {
        odalar.put(o.ad.toLowerCase(Locale.ROOT), o);
        indeksYenile();
    }

    void sil(String ad) {
        odalar.remove(ad.toLowerCase(Locale.ROOT));
        indeksYenile();
    }

    static String anahtar(String dunya, int x, int y, int z) {
        return dunya + ":" + x + ":" + y + ":" + z;
    }

    void indeksYenile() {
        kapiIndeks.clear();
        for (Oda o : odalar.values()) {
            for (Oda.Kapi k : o.kapilar) kapiIndeks.put(anahtar(o.dunya, k.x, k.y, k.z), o);
        }
    }

    Oda kapidan(Block b) {
        return kapiIndeks.get(anahtar(b.getWorld().getName(), b.getX(), b.getY(), b.getZ()));
    }

    Oda bolgeden(Location l) {
        for (Oda o : odalar.values()) if (o.bolgedeMi(l)) return o;
        return null;
    }

    // ---------------- Yükleme / Kaydetme ----------------

    void yukle() {
        odalar.clear();
        sunucuSpawn = null;
        if (!dosya.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dosya);
        sunucuSpawn = konumOku(y.getConfigurationSection("sunucu-spawn"));
        ConfigurationSection kok = y.getConfigurationSection("odalar");
        if (kok != null) {
            for (String ad : kok.getKeys(false)) {
                ConfigurationSection s = kok.getConfigurationSection(ad);
                if (s == null) continue;
                Oda o = new Oda(ad);
                o.dunya = s.getString("dunya", "");
                o.bolgeVar = s.getBoolean("bolge-var", false);
                o.minX = s.getInt("min.x");
                o.minY = s.getInt("min.y");
                o.minZ = s.getInt("min.z");
                o.maxX = s.getInt("max.x");
                o.maxY = s.getInt("max.y");
                o.maxZ = s.getInt("max.z");
                o.spawn1 = konumOku(s.getConfigurationSection("spawn1"));
                o.spawn2 = konumOku(s.getConfigurationSection("spawn2"));
                o.dis = konumOku(s.getConfigurationSection("dis"));
                String es = s.getString("esya-dusme", "");
                o.esyaDusme = es.equals("ac") ? Boolean.TRUE : es.equals("kapat") ? Boolean.FALSE : null;
                int md = s.getInt("mac-dakika", 0);
                o.macDakika = md > 0 ? md : null;
                for (String satir : s.getStringList("kapilar")) {
                    String[] p = satir.split(",");
                    if (p.length < 4) continue;
                    try {
                        o.kapilar.add(new Oda.Kapi(Integer.parseInt(p[0]), Integer.parseInt(p[1]),
                                Integer.parseInt(p[2]), p[3]));
                    } catch (NumberFormatException ex) {
                        plugin.getLogger().warning("Bozuk kapı kaydı atlandı: " + satir);
                    }
                }
                odalar.put(ad.toLowerCase(Locale.ROOT), o);
            }
        }
        indeksYenile();
    }

    void kaydet() {
        YamlConfiguration y = new YamlConfiguration();
        konumYaz(y, "sunucu-spawn", sunucuSpawn);
        for (Oda o : odalar.values()) {
            String p = "odalar." + o.ad + ".";
            y.set(p + "dunya", o.dunya);
            y.set(p + "bolge-var", o.bolgeVar);
            y.set(p + "min.x", o.minX);
            y.set(p + "min.y", o.minY);
            y.set(p + "min.z", o.minZ);
            y.set(p + "max.x", o.maxX);
            y.set(p + "max.y", o.maxY);
            y.set(p + "max.z", o.maxZ);
            konumYaz(y, p + "spawn1", o.spawn1);
            konumYaz(y, p + "spawn2", o.spawn2);
            konumYaz(y, p + "dis", o.dis);
            if (o.esyaDusme != null) y.set(p + "esya-dusme", o.esyaDusme ? "ac" : "kapat");
            if (o.macDakika != null) y.set(p + "mac-dakika", o.macDakika);
            List<String> kl = new ArrayList<>();
            for (Oda.Kapi k : o.kapilar) kl.add(k.x + "," + k.y + "," + k.z + "," + k.orijinal);
            y.set(p + "kapilar", kl);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(dosya);
        } catch (IOException e) {
            plugin.getLogger().severe("odalar.yml kaydedilemedi: " + e.getMessage());
        }
    }

    private static Oda.Konum konumOku(ConfigurationSection s) {
        if (s == null || !s.contains("dunya")) return null;
        return new Oda.Konum(s.getString("dunya", ""), s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                (float) s.getDouble("yaw"), (float) s.getDouble("pitch"));
    }

    private static void konumYaz(YamlConfiguration y, String yol, Oda.Konum k) {
        if (k == null) return;
        y.set(yol + ".dunya", k.dunya());
        y.set(yol + ".x", k.x());
        y.set(yol + ".y", k.y());
        y.set(yol + ".z", k.z());
        y.set(yol + ".yaw", (double) k.yaw());
        y.set(yol + ".pitch", (double) k.pitch());
    }
}
