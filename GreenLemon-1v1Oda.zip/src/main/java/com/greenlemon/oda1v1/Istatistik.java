package com.greenlemon.oda1v1;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Oyuncu 1v1 istatistikleri (stats.yml). Ana thread. */
final class Istatistik {
    static final class Kayit {
        String ad = "?";
        int kazanma;
        int kayip;
        int beraberlik;
    }

    private final OdaPlugin plugin;
    private final File dosya;
    private final Map<UUID, Kayit> kayitlar = new HashMap<>();

    Istatistik(OdaPlugin plugin) {
        this.plugin = plugin;
        this.dosya = new File(plugin.getDataFolder(), "stats.yml");
    }

    void yukle() {
        kayitlar.clear();
        if (!dosya.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dosya);
        ConfigurationSection kok = y.getConfigurationSection("oyuncular");
        if (kok == null) return;
        for (String anahtar : kok.getKeys(false)) {
            ConfigurationSection s = kok.getConfigurationSection(anahtar);
            if (s == null) continue;
            try {
                Kayit k = new Kayit();
                k.ad = s.getString("ad", "?");
                k.kazanma = s.getInt("kazanma");
                k.kayip = s.getInt("kayip");
                k.beraberlik = s.getInt("beraberlik");
                kayitlar.put(UUID.fromString(anahtar), k);
            } catch (IllegalArgumentException ignored) {
                // bozuk uuid
            }
        }
    }

    private Kayit al(UUID id, String ad) {
        Kayit k = kayitlar.computeIfAbsent(id, x -> new Kayit());
        if (ad != null) k.ad = ad;
        return k;
    }

    void kazanma(UUID id, String ad) {
        al(id, ad).kazanma++;
        kaydet();
    }

    void kayip(UUID id, String ad) {
        al(id, ad).kayip++;
        kaydet();
    }

    void beraberlik(UUID id, String ad) {
        al(id, ad).beraberlik++;
        kaydet();
    }

    Kayit bul(UUID id) {
        return kayitlar.get(id);
    }

    Kayit bulAd(String ad) {
        for (Kayit k : kayitlar.values()) if (k.ad.equalsIgnoreCase(ad)) return k;
        return null;
    }

    List<Kayit> top(int n) {
        List<Kayit> l = new ArrayList<>(kayitlar.values());
        l.sort(Comparator.comparingInt((Kayit k) -> k.kazanma).reversed());
        return l.size() > n ? l.subList(0, n) : l;
    }

    void kaydet() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Kayit> e : kayitlar.entrySet()) {
            String p = "oyuncular." + e.getKey() + ".";
            y.set(p + "ad", e.getValue().ad);
            y.set(p + "kazanma", e.getValue().kazanma);
            y.set(p + "kayip", e.getValue().kayip);
            y.set(p + "beraberlik", e.getValue().beraberlik);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(dosya);
        } catch (IOException ex) {
            plugin.getLogger().severe("stats.yml kaydedilemedi: " + ex.getMessage());
        }
    }
}
