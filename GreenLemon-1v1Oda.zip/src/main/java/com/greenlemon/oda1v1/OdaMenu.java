package com.greenlemon.oda1v1;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** /1v1 menüsü: odaların canlı durumu + kendi istatistiğin. */
final class OdaMenu implements InventoryHolder {
    static final int YENILE_SLOT = 40;
    private static final int[] SLOTLAR = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};

    private final OdaPlugin plugin;
    private final Player oyuncu;
    private final Inventory inv;

    OdaMenu(OdaPlugin plugin, Player oyuncu) {
        this.plugin = plugin;
        this.oyuncu = oyuncu;
        this.inv = Bukkit.createInventory(this, 45, Yazi.renk("&8GreenLemon | 1v1 Odaları"));
    }

    void ac(Player p) {
        yenile();
        p.openInventory(inv);
    }

    void yenile() {
        inv.clear();
        ItemStack cam = esya(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, cam);

        // Odalar
        int i = 0;
        for (Oda o : plugin.odalar().tum()) {
            if (i >= SLOTLAR.length) break;
            inv.setItem(SLOTLAR[i++], odaEsyasi(o));
        }
        if (i == 0) {
            inv.setItem(22, esya(Material.BARRIER, "&cHenüz oda yok", List.of("&7Yetkililer /1v1 olustur ile oda kurar.")));
        }

        // İstatistik
        inv.setItem(4, istatistikEsyasi());
        inv.setItem(YENILE_SLOT, esya(Material.CLOCK, "&aYenile", List.of("&7Oda durumlarını güncelle")));
    }

    private ItemStack odaEsyasi(Oda o) {
        Yonetici y = plugin.yonetici();
        Material mat = switch (o.durum) {
            case ACIK -> Material.LIME_CONCRETE;
            case BEKLEME -> Material.YELLOW_CONCRETE;
            default -> Material.RED_CONCRETE;
        };
        List<String> lore = new ArrayList<>();
        lore.add("&7Durum: " + y.durumYazi(o));
        List<UUID> icerde = y.odadakiler(o);
        if (!icerde.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (UUID u : icerde) sb.append(y.adGetir(u)).append(' ');
            lore.add("&7Oyuncular: &f" + sb.toString().trim());
        }
        long kalan = switch (o.durum) {
            case MAC -> (o.macBitis - System.currentTimeMillis()) / 1000;
            case BITIS -> (o.bitisBitis - System.currentTimeMillis()) / 1000;
            default -> -1;
        };
        if (kalan >= 0) lore.add("&7Kalan: &f" + String.format("%d:%02d", kalan / 60, kalan % 60));
        lore.add("");
        lore.add("&7Maç süresi: &f" + y.macSureMs(o) / 60_000L + " dk");
        lore.add("&7Eşya düşme: " + (y.esyaDusuyor(o) ? "&cEvet (kaybeden eşyalarını kaybeder)" : "&aHayır (eşyalar korunur)"));
        if (!o.hazirMi()) lore.add("&cOda hazır değil: " + String.join(", ", o.eksikler()));
        else if (o.durum == Oda.Durum.ACIK) lore.add("&aGirmek için kapıdaki cama dokun!");
        return esya(mat, "&e" + o.ad, lore);
    }

    private ItemStack istatistikEsyasi() {
        ItemStack head = new ItemStack(Material.PLAYER_HEAD);
        ItemMeta meta = head.getItemMeta();
        if (meta instanceof SkullMeta sm) sm.setOwningPlayer(oyuncu);
        meta.setDisplayName(Yazi.renk("&6" + oyuncu.getName() + " &7- 1v1 istatistiğin"));
        Istatistik.Kayit k = plugin.istatistik().bul(oyuncu.getUniqueId());
        List<String> lore = new ArrayList<>();
        if (k == null) {
            lore.add(Yazi.renk("&7Henüz maç oynamadın."));
        } else {
            int toplam = k.kazanma + k.kayip + k.beraberlik;
            lore.add(Yazi.renk("&aKazanma: &f" + k.kazanma));
            lore.add(Yazi.renk("&cKayıp: &f" + k.kayip));
            lore.add(Yazi.renk("&eBeraberlik: &f" + k.beraberlik));
            lore.add(Yazi.renk("&7Oran: &f" + (toplam == 0 ? "-" : String.format("%.0f%%", 100.0 * k.kazanma / toplam))));
        }
        meta.setLore(lore);
        head.setItemMeta(meta);
        return head;
    }

    private static ItemStack esya(Material m, String ad, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(Yazi.renk(ad));
        List<String> l = new ArrayList<>();
        for (String s : lore) l.add(Yazi.renk(s));
        meta.setLore(l);
        it.setItemMeta(meta);
        return it;
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }
}
