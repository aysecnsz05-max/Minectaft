package com.greenlemon.oda1v1;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.MultipleFacing;
import org.bukkit.block.data.Waterlogged;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.command.Command;
import org.bukkit.entity.AbstractArrow;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ExperienceOrb;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.BoundingBox;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Maç akışının tamamı: giriş, geri sayım, dövüş, bitiş, sıfırlama. Sadece ana thread. */
final class Yonetici {
    private final OdaPlugin plugin;
    private final Map<UUID, Oda> oyuncuOda = new HashMap<>();
    private final Map<UUID, Location> respawnHedef = new HashMap<>();
    private final Map<UUID, Long> tiklama = new HashMap<>();
    private BukkitTask ticker;

    Yonetici(OdaPlugin plugin) {
        this.plugin = plugin;
    }

    void baslat() {
        ticker = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    Oda oda(Player p) {
        return oyuncuOda.get(p.getUniqueId());
    }

    Location respawnKonum(UUID id) {
        return respawnHedef.remove(id);
    }

    // ================= Kapı tıklama =================

    void kapiTiklandi(Player p, Oda o) {
        long simdi = System.currentTimeMillis();
        Long son = tiklama.get(p.getUniqueId());
        if (son != null && simdi - son < 800) return;
        tiklama.put(p.getUniqueId(), simdi);

        Oda mevcut = oyuncuOda.get(p.getUniqueId());
        if (mevcut != null) {
            if (mevcut != o) {
                p.sendMessage(plugin.m("baska-odada"));
                return;
            }
            cikisDene(p, o);
            return;
        }
        girisDene(p, o);
    }

    private void girisDene(Player p, Oda o) {
        if (!p.hasPermission("greenlemon.oda.kullan")) {
            p.sendMessage(plugin.m("yetki-yok"));
            return;
        }
        if (!o.hazirMi()) {
            p.sendMessage(plugin.m("oda-hazir-degil", "{eksik}", String.join(", ", o.eksikler())));
            plugin.ses(p, "hata", 1f);
            return;
        }
        GameMode gm = p.getGameMode();
        if (gm == GameMode.CREATIVE || gm == GameMode.SPECTATOR) {
            p.sendMessage(plugin.m("oyun-modu"));
            plugin.ses(p, "hata", 1f);
            return;
        }

        switch (o.durum) {
            case ACIK -> {
                Location l = o.spawn1.al();
                if (l == null) return;
                o.p1 = p.getUniqueId();
                o.p2 = null;
                o.kazanan = null;
                oyuncuOda.put(p.getUniqueId(), o);
                p.teleport(l);
                o.durum = Oda.Durum.BEKLEME;
                o.beklemeBasi = System.currentTimeMillis();
                p.sendMessage(plugin.m("giris-bekleme"));
                plugin.ses(p, "giris", 1f);
                barGuncelle(o, plugin.m("bar-bekleme"), BarColor.YELLOW, 1.0);
                kapiBoya(o);
            }
            case BEKLEME -> {
                Location l = o.spawn2.al();
                if (l == null) return;
                o.p2 = p.getUniqueId();
                oyuncuOda.put(p.getUniqueId(), o);
                p.teleport(l);
                plugin.ses(p, "giris", 1f);
                geriSayimBaslat(o);
            }
            case GERI_SAYIM, MAC -> {
                p.sendMessage(plugin.m("oda-dolu"));
                plugin.ses(p, "hata", 1f);
            }
            case BITIS -> {
                long kalan = Math.max(1, (o.bitisBitis - System.currentTimeMillis() + 999) / 1000);
                p.sendMessage(plugin.m("oda-hazirlaniyor", "{saniye}", String.valueOf(kalan)));
                plugin.ses(p, "hata", 1f);
            }
        }
    }

    private void cikisDene(Player p, Oda o) {
        UUID id = p.getUniqueId();
        if (o.durum == Oda.Durum.BEKLEME && id.equals(o.p1)) {
            oyuncuOda.remove(id);
            odayiBosalt(o);
            ayril(p, o);
            return;
        }
        if (o.durum == Oda.Durum.BITIS && id.equals(o.kazanan)) {
            oyuncuOda.remove(id);
            if (o.bar != null) o.bar.removePlayer(p);
            ayril(p, o);
            return;
        }
        p.sendMessage(plugin.m("cikis-yasak"));
        plugin.ses(p, "hata", 1f);
    }

    private void ayril(Player p, Oda o) {
        Location dis = o.dis != null ? o.dis.al() : null;
        p.teleport(dis != null ? dis : plugin.sunucuSpawn());
        p.sendMessage(plugin.m("cikti"));
    }

    // ================= Maç akışı =================

    private void geriSayimBaslat(Oda o) {
        o.durum = Oda.Durum.GERI_SAYIM;
        o.geriSayim = plugin.getConfig().getInt("sureler.geri-sayim", 5);
        Player a = Bukkit.getPlayer(o.p1);
        Player b = Bukkit.getPlayer(o.p2);
        if (a == null || b == null) return;

        Location l1 = o.spawn1.al();
        if (l1 != null) a.teleport(l1);
        hazirla(a);
        hazirla(b);
        a.sendMessage(plugin.m("giris-rakip", "{rakip}", b.getName(), "{saniye}", String.valueOf(o.geriSayim)));
        b.sendMessage(plugin.m("giris-rakip", "{rakip}", a.getName(), "{saniye}", String.valueOf(o.geriSayim)));
        barGuncelle(o, plugin.m("bar-geri-sayim", "{sayi}", String.valueOf(o.geriSayim)), BarColor.YELLOW, 1.0);
        kapiBoya(o);
    }

    private void macBaslat(Oda o) {
        Player a = Bukkit.getPlayer(o.p1);
        Player b = Bukkit.getPlayer(o.p2);
        if (a == null || b == null) return;
        o.durum = Oda.Durum.MAC;
        o.macBitis = System.currentTimeMillis() + macSureMs(o);
        o.uyarilar.clear();
        for (Player p : new Player[]{a, b}) {
            p.setGameMode(GameMode.SURVIVAL);
            hazirla(p);
            p.sendTitle(plugin.m("mac-baslik"), plugin.m("mac-alt"), 0, 30, 10);
            plugin.ses(p, "basla", 1f);
        }
    }

    private void hazirla(Player p) {
        if (!plugin.getConfig().getBoolean("mac.iyilestir", true)) return;
        AttributeInstance max = p.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        p.setHealth(max != null ? max.getValue() : 20.0);
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setFireTicks(0);
        p.setFallDistance(0f);
        for (PotionEffect ef : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(ef.getType());
    }

    /** Maçta ölüm. Kazananı belirler. */
    void olumIsle(Player kurban, PlayerDeathEvent e) {
        Oda o = oyuncuOda.get(kurban.getUniqueId());
        if (o == null) return;
        UUID id = kurban.getUniqueId();

        boolean koru = !esyaDusuyor(o);
        if (o.durum != Oda.Durum.MAC) koru = true; // maç dışı ölümde eşya kaybolmasın
        e.setKeepInventory(koru);
        if (koru) {
            e.getDrops().clear();
            e.setKeepLevel(true);
            e.setDroppedExp(0);
        }
        if (plugin.getConfig().getBoolean("mac.olum-mesaji-gizle", true)) e.setDeathMessage(null);

        respawnHedef.put(id, plugin.sunucuSpawn());
        if (plugin.getConfig().getBoolean("mac.otomatik-respawn", true)) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (kurban.isOnline() && kurban.isDead()) kurban.spigot().respawn();
            });
        }

        if (o.durum == Oda.Durum.MAC) {
            UUID rakip = o.rakip(id);
            if (rakip != null) {
                bitir(o, rakip, id);
                return;
            }
        }
        oyuncuAyrildi(kurban);
    }

    /** Oyuncu çıkış yaptı veya (maç dışında) öldü. */
    void oyuncuAyrildi(Player p) {
        UUID id = p.getUniqueId();
        Oda o = oyuncuOda.get(id);
        if (o == null) return;

        switch (o.durum) {
            case BEKLEME -> {
                oyuncuOda.remove(id);
                odayiBosalt(o);
            }
            case GERI_SAYIM -> {
                UUID kalan = o.rakip(id);
                oyuncuOda.remove(id);
                if (o.bar != null) o.bar.removePlayer(p);
                Player k = kalan == null ? null : Bukkit.getPlayer(kalan);
                if (k == null) {
                    odayiBosalt(o);
                    return;
                }
                o.p1 = kalan;
                o.p2 = null;
                o.durum = Oda.Durum.BEKLEME;
                o.beklemeBasi = System.currentTimeMillis();
                Location l = o.spawn1 != null ? o.spawn1.al() : null;
                if (l != null) k.teleport(l);
                k.sendMessage(plugin.m("rakip-ayrildi-bekleme"));
                barGuncelle(o, plugin.m("bar-bekleme"), BarColor.YELLOW, 1.0);
                kapiBoya(o);
            }
            case MAC -> {
                UUID rakip = o.rakip(id);
                if (rakip != null) {
                    Player r = Bukkit.getPlayer(rakip);
                    if (r != null) r.sendMessage(plugin.m("rakip-ayrildi"));
                    bitir(o, rakip, id);
                } else {
                    oyuncuOda.remove(id);
                    odayiBosalt(o);
                }
            }
            case BITIS -> {
                oyuncuOda.remove(id);
                if (o.bar != null) o.bar.removePlayer(p);
            }
            default -> oyuncuOda.remove(id);
        }
    }

    private void bitir(Oda o, UUID kazananId, UUID kaybedenId) {
        o.durum = Oda.Durum.BITIS;
        o.kazanan = kazananId;
        long bekleme = plugin.getConfig().getLong("sureler.bitis-bekleme-saniye", 30);
        o.bitisBitis = System.currentTimeMillis() + bekleme * 1000L;
        o.uyarilar.clear();

        String kzAd = ad(kazananId);
        String kbAd = ad(kaybedenId);
        plugin.istatistik().kazanma(kazananId, kzAd);
        plugin.istatistik().kayip(kaybedenId, kbAd);

        Player kb = Bukkit.getPlayer(kaybedenId);
        oyuncuOda.remove(kaybedenId);
        if (o.bar != null && kb != null) o.bar.removePlayer(kb);
        if (kb != null) kb.sendMessage(plugin.m("kaybettin-mesaj", "{kazanan}", kzAd));

        Player kz = Bukkit.getPlayer(kazananId);
        if (kz != null) {
            String sn = String.valueOf(bekleme);
            kz.sendTitle(plugin.m("kazandin-baslik"), plugin.m("kazandin-alt", "{saniye}", sn), 5, 50, 15);
            kz.sendMessage(plugin.m("kazandin-mesaj", "{saniye}", sn));
            plugin.ses(kz, "kazan", 1f);
        }
        if (plugin.getConfig().getBoolean("duyuru.kazanan", true)) {
            Bukkit.broadcastMessage(plugin.m("duyuru-kazanan", "{kazanan}", kzAd, "{kaybeden}", kbAd));
        }
        barGuncelle(o, plugin.m("bar-bitis", "{sure}", sureYazi(bekleme)), BarColor.GREEN, 1.0);
        kapiBoya(o);
    }

    private void beraberlik(Oda o) {
        for (UUID u : new UUID[]{o.p1, o.p2}) {
            if (u == null) continue;
            plugin.istatistik().beraberlik(u, ad(u));
            Player p = Bukkit.getPlayer(u);
            if (p != null) p.sendMessage(plugin.m("sure-doldu"));
        }
        odaSifirla(o, plugin.sunucuSpawn());
    }

    // ================= Tick =================

    private void tick() {
        long simdi = System.currentTimeMillis();
        for (Oda o : plugin.odalar().tum()) {
            switch (o.durum) {
                case BEKLEME -> beklemeTick(o, simdi);
                case GERI_SAYIM -> geriSayimTick(o);
                case MAC -> macTick(o, simdi);
                case BITIS -> bitisTick(o, simdi);
                default -> { }
            }
        }
    }

    private void beklemeTick(Oda o, long simdi) {
        long maks = plugin.getConfig().getLong("sureler.bekleme-maks-saniye", 300);
        if (maks <= 0 || o.p1 == null) return;
        if (simdi - o.beklemeBasi > maks * 1000L) {
            Player p = Bukkit.getPlayer(o.p1);
            oyuncuOda.remove(o.p1);
            odayiBosalt(o);
            if (p != null) {
                p.sendMessage(plugin.m("bekleme-zaman-asimi"));
                ayril(p, o);
            }
        }
    }

    private void geriSayimTick(Oda o) {
        Player a = o.p1 == null ? null : Bukkit.getPlayer(o.p1);
        Player b = o.p2 == null ? null : Bukkit.getPlayer(o.p2);
        if (a == null || b == null) return;
        if (o.geriSayim > 0) {
            String sayi = String.valueOf(o.geriSayim);
            for (Player p : new Player[]{a, b}) {
                p.sendTitle(plugin.m("geri-sayim-baslik", "{sayi}", sayi), plugin.m("geri-sayim-alt"), 0, 25, 0);
                plugin.ses(p, "geri-sayim", 1f);
            }
            barGuncelle(o, plugin.m("bar-geri-sayim", "{sayi}", sayi), BarColor.YELLOW,
                    (double) o.geriSayim / Math.max(1, plugin.getConfig().getInt("sureler.geri-sayim", 5)));
            o.geriSayim--;
        } else {
            macBaslat(o);
        }
    }

    private void macTick(Oda o, long simdi) {
        long kalanMs = o.macBitis - simdi;
        long toplamMs = macSureMs(o);
        long kalanSn = Math.max(0, (kalanMs + 999) / 1000);

        barGuncelle(o, plugin.m("bar-mac", "{sure}", sureYazi(kalanSn)), BarColor.RED,
                toplamMs <= 0 ? 0 : (double) kalanMs / toplamMs);

        for (int esik : new int[]{60, 30, 10}) {
            if (kalanSn <= esik && o.uyarilar.add(esik)) {
                for (UUID u : new UUID[]{o.p1, o.p2}) {
                    Player p = u == null ? null : Bukkit.getPlayer(u);
                    if (p == null) continue;
                    p.sendMessage(plugin.m("sure-uyari", "{saniye}", String.valueOf(esik)));
                    plugin.ses(p, "uyari", 1f);
                }
            }
        }

        if (plugin.getConfig().getBoolean("mac.sinir-kontrol", true)) {
            for (UUID u : new UUID[]{o.p1, o.p2}) {
                Player p = u == null ? null : Bukkit.getPlayer(u);
                if (p == null || o.bolgedeMi(p.getLocation())) continue;
                Oda.Konum k = o.spawnOf(u);
                Location l = k == null ? null : k.al();
                if (l != null) {
                    p.teleport(l);
                    p.sendMessage(plugin.m("sinir-uyari"));
                }
            }
        }

        if (kalanMs <= 0) beraberlik(o);
    }

    private void bitisTick(Oda o, long simdi) {
        if (o.kazanan != null && oyuncuOda.get(o.kazanan) == o) {
            Player w = Bukkit.getPlayer(o.kazanan);
            if (w != null && o.bolgeVar && !o.bolgedeMi(w.getLocation())) {
                // Kazanan odadan ayrıldı (/spawn vb.): artık odanın oyuncusu değil
                oyuncuOda.remove(o.kazanan);
                if (o.bar != null) o.bar.removePlayer(w);
            }
        }
        long kalanMs = o.bitisBitis - simdi;
        long kalanSn = Math.max(0, (kalanMs + 999) / 1000);
        long toplam = plugin.getConfig().getLong("sureler.bitis-bekleme-saniye", 30) * 1000L;
        barGuncelle(o, plugin.m("bar-bitis", "{sure}", sureYazi(kalanSn)), BarColor.GREEN,
                toplam <= 0 ? 0 : (double) kalanMs / toplam);
        if (kalanMs <= 0) {
            boolean dis = "DIS".equalsIgnoreCase(plugin.getConfig().getString("bitis.isinlanma", "SPAWN"));
            Location hedef = dis && o.dis != null ? o.dis.al() : null;
            odaSifirla(o, hedef != null ? hedef : plugin.sunucuSpawn());
        }
    }

    // ================= Sıfırlama =================

    /** Odadaki herkesi hedefe gönderir, eşyaları temizler, odayı açar. */
    void odaSifirla(Oda o, Location hedef) {
        List<UUID> icerdekiler = new ArrayList<>();
        for (Map.Entry<UUID, Oda> e : oyuncuOda.entrySet()) if (e.getValue() == o) icerdekiler.add(e.getKey());
        for (UUID u : icerdekiler) {
            oyuncuOda.remove(u);
            Player p = Bukkit.getPlayer(u);
            // Odanın dışına çıkmış (örn. /spawn çekmiş) oyuncuyu tekrar ışınlama
            if (p != null && hedef != null && (!o.bolgeVar || o.bolgedeMi(p.getLocation()))) p.teleport(hedef);
        }
        odayiBosalt(o);
    }

    /** Oda durumunu ACIK'a döndürür (oyuncuları ışınlamaz). */
    private void odayiBosalt(Oda o) {
        barKaldir(o);
        temizle(o);
        o.durum = Oda.Durum.ACIK;
        o.p1 = null;
        o.p2 = null;
        o.kazanan = null;
        o.geriSayim = 0;
        o.uyarilar.clear();
        kapiBoya(o);
    }

    private void temizle(Oda o) {
        if (!plugin.getConfig().getBoolean("bitis.esyalari-temizle", true)) return;
        World w = Bukkit.getWorld(o.dunya);
        if (w == null || !o.bolgeVar) return;
        BoundingBox kutu = new BoundingBox(o.minX, o.minY, o.minZ, o.maxX + 1, o.maxY + 1, o.maxZ + 1);
        for (Entity en : w.getNearbyEntities(kutu)) {
            if (en instanceof Item || en instanceof ExperienceOrb || en instanceof AbstractArrow) en.remove();
        }
    }

    void tumOdalariSifirla() {
        for (Oda o : plugin.odalar().tum()) odaSifirla(o, plugin.sunucuSpawn());
        respawnHedef.clear();
    }

    /** Eklenti kapanırken: herkesi spawn'a gönder, kapıları yeşile boya. */
    void kapat() {
        if (ticker != null) ticker.cancel();
        for (Oda o : plugin.odalar().tum()) {
            for (Oda.Kapi k : o.kapilar) kapiBoyaTek(o, k, "LIME");
            barKaldir(o);
        }
        Location sp = plugin.sunucuSpawn();
        for (UUID u : new ArrayList<>(oyuncuOda.keySet())) {
            Player p = Bukkit.getPlayer(u);
            if (p != null) p.teleport(sp);
        }
        oyuncuOda.clear();
    }

    // ================= Kapı rengi =================

    void tumKapilariBoya() {
        for (Oda o : plugin.odalar().tum()) kapiBoya(o);
    }

    void kapiBoya(Oda o) {
        if (!plugin.getConfig().getBoolean("kapi-renk", true)) return;
        String renk = switch (o.durum) {
            case ACIK -> "LIME";
            case BEKLEME -> "YELLOW";
            default -> "RED";
        };
        for (Oda.Kapi k : o.kapilar) kapiBoyaTek(o, k, renk);
    }

    private void kapiBoyaTek(Oda o, Oda.Kapi k, String renk) {
        if (!plugin.getConfig().getBoolean("kapi-renk", true) || !k.cam()) return;
        World w = Bukkit.getWorld(o.dunya);
        if (w == null) return;
        Material hedef = Material.matchMaterial(renk + "_STAINED_GLASS" + (k.panel() ? "_PANE" : ""));
        if (hedef == null) return;
        blokDegistir(w.getBlockAt(k.x, k.y, k.z), hedef);
    }

    /** Kapı kaldırılırken orijinal bloğa döndürür. */
    void kapiGeriYukle(Oda o, Oda.Kapi k) {
        World w = Bukkit.getWorld(o.dunya);
        Material m = Material.matchMaterial(k.orijinal);
        if (w == null || m == null) return;
        blokDegistir(w.getBlockAt(k.x, k.y, k.z), m);
    }

    private void blokDegistir(Block b, Material hedef) {
        if (b.getType() == hedef) return;
        BlockData eski = b.getBlockData();
        BlockData yeni = hedef.createBlockData();
        if (eski instanceof MultipleFacing em && yeni instanceof MultipleFacing ym) {
            for (BlockFace f : em.getAllowedFaces()) {
                if (ym.getAllowedFaces().contains(f)) ym.setFace(f, em.hasFace(f));
            }
        }
        if (eski instanceof Waterlogged ew && yeni instanceof Waterlogged yw) {
            yw.setWaterlogged(ew.isWaterlogged());
        }
        b.setBlockData(yeni, false);
    }

    // ================= Boss bar =================

    private void barGuncelle(Oda o, String baslik, BarColor renk, double ilerleme) {
        if (o.bar == null) o.bar = Bukkit.createBossBar("", renk, BarStyle.SOLID);
        o.bar.setTitle(baslik);
        o.bar.setColor(renk);
        o.bar.setProgress(Math.max(0.0, Math.min(1.0, ilerleme)));
        for (Map.Entry<UUID, Oda> e : oyuncuOda.entrySet()) {
            if (e.getValue() != o) continue;
            Player p = Bukkit.getPlayer(e.getKey());
            if (p != null && !o.bar.getPlayers().contains(p)) o.bar.addPlayer(p);
        }
    }

    private void barKaldir(Oda o) {
        if (o.bar != null) {
            o.bar.removeAll();
            o.bar = null;
        }
    }

    // ================= Komut engeli =================

    boolean komutYasakMi(String ham) {
        String c = ham.startsWith("/") ? ham.substring(1) : ham;
        c = c.strip().toLowerCase(Locale.ROOT);
        if (c.isEmpty()) return false;
        String etiket = c.split("\\s+")[0];
        int i = etiket.indexOf(':');
        if (i >= 0) etiket = etiket.substring(i + 1);
        if (etiket.equals("1v1")) return false;

        Set<String> adaylar = new HashSet<>();
        adaylar.add(etiket);
        try {
            Command cmd = Bukkit.getCommandMap().getCommand(etiket);
            if (cmd != null) {
                adaylar.add(cmd.getName().toLowerCase(Locale.ROOT));
                for (String al : cmd.getAliases()) adaylar.add(al.toLowerCase(Locale.ROOT));
            }
        } catch (Throwable ignored) {
            // komut haritasına erişilemezse sadece yazılana bak
        }

        boolean beyaz = "BEYAZ_LISTE".equalsIgnoreCase(plugin.getConfig().getString("komut-modu", "KARA_LISTE"));
        List<String> liste = new ArrayList<>();
        for (String s : plugin.getConfig().getStringList(beyaz ? "izinli-komutlar" : "yasakli-komutlar")) {
            liste.add(s.toLowerCase(Locale.ROOT));
        }
        boolean eslesti = false;
        for (String a : adaylar) if (liste.contains(a)) eslesti = true;
        return beyaz ? !eslesti : eslesti;
    }

    /** Oyuncu şu an komut engeline tabi mi? (Kazanan 30 sn'de serbest.) */
    boolean komutEngelli(Player p) {
        Oda o = oyuncuOda.get(p.getUniqueId());
        return o != null && o.durum != Oda.Durum.BITIS;
    }

    boolean rakipMi(Oda o, Player a, Player b) {
        return a.getUniqueId().equals(o.rakip(b.getUniqueId()));
    }

    // ================= Yardımcılar =================

    private static String ad(UUID id) {
        Player p = Bukkit.getPlayer(id);
        if (p != null) return p.getName();
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? "?" : n;
    }

    private static String sureYazi(long sn) {
        return String.format("%d:%02d", sn / 60, sn % 60);
    }

    /** Odanın maç süresi (oda ayarı varsa o, yoksa config). */
    long macSureMs(Oda o) {
        long dk = o.macDakika != null ? o.macDakika : plugin.getConfig().getLong("sureler.mac-dakika", 8);
        return dk * 60_000L;
    }

    /** Ölen oyuncunun eşyaları düşer mi? (oda ayarı varsa o, yoksa config) */
    boolean esyaDusuyor(Oda o) {
        if (o.esyaDusme != null) return o.esyaDusme;
        return !plugin.getConfig().getBoolean("mac.envanter-koru", false);
    }

    /** Admin işlemi: odayı zorla sıfırla. */
    void zorlaSifirla(Oda o) {
        odaSifirla(o, plugin.sunucuSpawn());
    }

    String durumYazi(Oda o) {
        return switch (o.durum) {
            case ACIK -> "&aBoş";
            case BEKLEME -> "&eRakip bekliyor";
            case GERI_SAYIM -> "&6Başlıyor";
            case MAC -> "&cMaç sürüyor";
            case BITIS -> "&bKilitli (yenileniyor)";
        };
    }

    List<UUID> odadakiler(Oda o) {
        List<UUID> l = new ArrayList<>();
        for (Map.Entry<UUID, Oda> e : oyuncuOda.entrySet()) if (e.getValue() == o) l.add(e.getKey());
        return l;
    }

    String adGetir(UUID id) {
        return ad(id);
    }
}
