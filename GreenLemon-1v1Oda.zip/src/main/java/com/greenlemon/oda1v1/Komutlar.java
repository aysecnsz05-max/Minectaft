package com.greenlemon.oda1v1;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

final class Komutlar implements TabExecutor {
    private static final Pattern ISIM = Pattern.compile("^[A-Za-z0-9_-]{2,20}$");
    private static final String ADMIN = "greenlemon.oda.admin";
    private static final List<String> ADMIN_ALT = List.of("balta", "olustur", "sil", "bolge", "spawn1", "spawn2",
            "dis", "kapiekle", "kapisil", "liste", "bilgi", "sifirla", "spawnayarla", "reload", "esya", "sure");
    private static final List<String> ODA_ALT = List.of("sil", "bolge", "spawn1", "spawn2", "dis", "kapiekle",
            "kapisil", "bilgi", "sifirla", "esya", "sure");

    private final OdaPlugin plugin;

    Komutlar(OdaPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        String alt = a.length > 0 ? a[0].toLowerCase(Locale.ROOT) : "menu";
        if (alt.equals("menu")) {
            if (s instanceof Player p) new OdaMenu(plugin).ac(p);
            else yardim(s);
            return true;
        }
        if (alt.equals("istatistik") || alt.equals("stat")) {
            istatistik(s, a);
            return true;
        }
        if (alt.equals("top")) {
            top(s);
            return true;
        }
        if (alt.equals("yardim") || !ADMIN_ALT.contains(alt)) {
            yardim(s);
            return true;
        }
        if (!s.hasPermission(ADMIN)) {
            s.sendMessage(plugin.m("yetki-yok"));
            return true;
        }
        admin(s, alt, a);
        return true;
    }

    private void yardim(CommandSender s) {
        for (String l : plugin.mListe("yardim-oyuncu")) s.sendMessage(l);
        if (s.hasPermission(ADMIN)) for (String l : plugin.mListe("yardim-admin")) s.sendMessage(l);
    }

    // ---------------- Oyuncu komutları ----------------

    private void istatistik(CommandSender s, String[] a) {
        Istatistik.Kayit k;
        String ad;
        if (a.length > 1) {
            ad = a[1];
            k = plugin.istatistik().bulAd(ad);
        } else if (s instanceof Player p) {
            ad = p.getName();
            k = plugin.istatistik().bul(p.getUniqueId());
        } else {
            s.sendMessage(plugin.m("sadece-oyuncu"));
            return;
        }
        if (k == null) {
            s.sendMessage(plugin.m("istatistik-yok"));
            return;
        }
        int toplam = k.kazanma + k.kayip + k.beraberlik;
        String oran = toplam == 0 ? "-" : String.format("%.0f%%", 100.0 * k.kazanma / toplam);
        s.sendMessage(plugin.m("istatistik-baslik", "{oyuncu}", k.ad));
        s.sendMessage(plugin.m("istatistik-satir", "{kazanma}", String.valueOf(k.kazanma),
                "{kayip}", String.valueOf(k.kayip), "{beraberlik}", String.valueOf(k.beraberlik), "{oran}", oran));
    }

    private void top(CommandSender s) {
        List<Istatistik.Kayit> l = plugin.istatistik().top(10);
        if (l.isEmpty()) {
            s.sendMessage(plugin.m("istatistik-yok"));
            return;
        }
        s.sendMessage(plugin.m("top-baslik"));
        int i = 1;
        for (Istatistik.Kayit k : l) {
            s.sendMessage(plugin.m("top-satir", "{sira}", String.valueOf(i++), "{oyuncu}", k.ad,
                    "{kazanma}", String.valueOf(k.kazanma)));
        }
    }

    // ---------------- Yetkili komutları ----------------

    private void admin(CommandSender s, String alt, String[] a) {
        switch (alt) {
            case "balta" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage(plugin.m("sadece-oyuncu"));
                    return;
                }
                var kalan = p.getInventory().addItem(plugin.baltaOlustur());
                for (ItemStack it : kalan.values()) p.getWorld().dropItem(p.getLocation(), it);
                p.sendMessage(plugin.m("balta-verildi"));
            }
            case "liste" -> {
                s.sendMessage(plugin.m("liste-baslik"));
                for (Oda o : plugin.odalar().tum()) {
                    s.sendMessage(plugin.m("liste-satir", "{oda}", o.ad, "{durum}", plugin.yonetici().durumYazi(o),
                            "{hazir}", o.hazirMi() ? "hazır" : "eksik: " + String.join(", ", o.eksikler())));
                }
            }
            case "spawnayarla" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage(plugin.m("sadece-oyuncu"));
                    return;
                }
                plugin.odalar().sunucuSpawn = Oda.Konum.of(p.getLocation());
                plugin.odalar().kaydet();
                s.sendMessage(plugin.m("spawn-ayarlandi"));
            }
            case "reload" -> {
                plugin.yenidenYukle();
                s.sendMessage(plugin.m("yeniden-yuklendi", "{sayi}", String.valueOf(plugin.odalar().tum().size())));
            }
            case "olustur" -> olustur(s, a, false);
            case "bolge" -> olustur(s, a, true);
            default -> odaKomutu(s, alt, a);
        }
    }

    private void olustur(CommandSender s, String[] a, boolean guncelle) {
        if (!(s instanceof Player p)) {
            s.sendMessage(plugin.m("sadece-oyuncu"));
            return;
        }
        if (a.length < 2 || !ISIM.matcher(a[1]).matches()) {
            s.sendMessage(plugin.m("isim-gecersiz"));
            return;
        }
        Oda var = plugin.odalar().al(a[1]);
        if (guncelle && var == null) {
            s.sendMessage(plugin.m("oda-yok"));
            return;
        }
        if (!guncelle && var != null) {
            s.sendMessage(plugin.m("oda-var"));
            return;
        }
        OdaPlugin.Secim sec = plugin.secimler().get(p.getUniqueId());
        if (sec == null || sec.a == null || sec.b == null) {
            s.sendMessage(plugin.m("secim-eksik"));
            return;
        }
        if (sec.a.getWorld() == null || !sec.a.getWorld().equals(sec.b.getWorld())) {
            s.sendMessage(plugin.m("secim-dunya"));
            return;
        }
        if (guncelle) {
            var.bolgeAyarla(sec.a.getWorld().getName(), sec.a, sec.b);
            plugin.odalar().kaydet();
            plugin.odalar().indeksYenile();
            s.sendMessage(plugin.m("bolge-guncellendi", "{oda}", var.ad));
        } else {
            Oda o = new Oda(a[1]);
            o.bolgeAyarla(sec.a.getWorld().getName(), sec.a, sec.b);
            plugin.odalar().ekle(o);
            plugin.odalar().kaydet();
            s.sendMessage(plugin.m("oda-olusturuldu", "{oda}", o.ad));
        }
    }

    private void odaKomutu(CommandSender s, String alt, String[] a) {
        if (a.length < 2) {
            s.sendMessage(plugin.m("oda-yok"));
            return;
        }
        Oda o = plugin.odalar().al(a[1]);
        if (o == null) {
            s.sendMessage(plugin.m("oda-yok"));
            return;
        }
        switch (alt) {
            case "sil" -> {
                plugin.yonetici().zorlaSifirla(o);
                for (Oda.Kapi k : new ArrayList<>(o.kapilar)) plugin.yonetici().kapiGeriYukle(o, k);
                plugin.odalar().sil(o.ad);
                plugin.odalar().kaydet();
                s.sendMessage(plugin.m("oda-silindi", "{oda}", o.ad));
            }
            case "sifirla" -> {
                plugin.yonetici().zorlaSifirla(o);
                s.sendMessage(plugin.m("sifirlandi", "{oda}", o.ad));
            }
            case "bilgi" -> bilgi(s, o);
            case "esya" -> {
                String v = a.length > 2 ? a[2].toLowerCase(Locale.ROOT) : "";
                if (v.equals("ac")) o.esyaDusme = Boolean.TRUE;
                else if (v.equals("kapat")) o.esyaDusme = Boolean.FALSE;
                else if (v.equals("varsayilan")) o.esyaDusme = null;
                else {
                    s.sendMessage(plugin.m("kullanim-esya"));
                    return;
                }
                plugin.odalar().kaydet();
                s.sendMessage(plugin.m("esya-ayarlandi", "{oda}", o.ad, "{deger}", v));
            }
            case "sure" -> {
                String v = a.length > 2 ? a[2].toLowerCase(Locale.ROOT) : "";
                if (v.equals("varsayilan")) {
                    o.macDakika = null;
                } else {
                    int dk;
                    try {
                        dk = Integer.parseInt(v);
                    } catch (NumberFormatException e) {
                        dk = -1;
                    }
                    if (dk < 1 || dk > 60) {
                        s.sendMessage(plugin.m("kullanim-sure"));
                        return;
                    }
                    o.macDakika = dk;
                }
                plugin.odalar().kaydet();
                s.sendMessage(plugin.m("sure-ayarlandi", "{oda}", o.ad, "{deger}", v));
            }
            case "spawn1", "spawn2", "dis" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage(plugin.m("sadece-oyuncu"));
                    return;
                }
                Oda.Konum k = Oda.Konum.of(p.getLocation());
                if (alt.equals("spawn1")) o.spawn1 = k;
                else if (alt.equals("spawn2")) o.spawn2 = k;
                else o.dis = k;
                plugin.odalar().kaydet();
                s.sendMessage(plugin.m("nokta-ayarlandi", "{oda}", o.ad, "{nokta}", alt));
            }
            case "kapiekle", "kapisil" -> kapi(s, alt, o);
            default -> s.sendMessage(plugin.m("oda-yok"));
        }
    }

    private void kapi(CommandSender s, String alt, Oda o) {
        if (!(s instanceof Player p)) {
            s.sendMessage(plugin.m("sadece-oyuncu"));
            return;
        }
        Block b = p.getTargetBlockExact(6);
        if (b == null || b.getType() == Material.AIR) {
            s.sendMessage(plugin.m("kapi-bakmiyor"));
            return;
        }
        Oda sahibi = plugin.odalar().kapidan(b);
        if (alt.equals("kapiekle")) {
            if (sahibi != null) {
                s.sendMessage(plugin.m(sahibi == o ? "kapi-eklendi" : "kapi-baska-oda",
                        "{sayi}", String.valueOf(o.kapilar.size()), "{oda}", o.ad));
                return;
            }
            if (o.kapilar.isEmpty()) o.dunya = o.bolgeVar ? o.dunya : b.getWorld().getName();
            o.kapilar.add(new Oda.Kapi(b.getX(), b.getY(), b.getZ(), b.getType().name()));
            plugin.odalar().indeksYenile();
            plugin.odalar().kaydet();
            plugin.yonetici().kapiBoya(o);
            s.sendMessage(plugin.m("kapi-eklendi", "{sayi}", String.valueOf(o.kapilar.size()), "{oda}", o.ad));
        } else {
            if (sahibi != o) {
                s.sendMessage(plugin.m("kapi-yok"));
                return;
            }
            Oda.Kapi bulunan = null;
            for (Oda.Kapi k : o.kapilar) {
                if (k.x == b.getX() && k.y == b.getY() && k.z == b.getZ()) bulunan = k;
            }
            if (bulunan == null) {
                s.sendMessage(plugin.m("kapi-yok"));
                return;
            }
            plugin.yonetici().kapiGeriYukle(o, bulunan);
            o.kapilar.remove(bulunan);
            plugin.odalar().indeksYenile();
            plugin.odalar().kaydet();
            s.sendMessage(plugin.m("kapi-silindi", "{sayi}", String.valueOf(o.kapilar.size())));
        }
    }

    private void bilgi(CommandSender s, Oda o) {
        s.sendMessage(plugin.m("bilgi-baslik", "{oda}", o.ad));
        satir(s, "Durum", plugin.yonetici().durumYazi(o));
        satir(s, "Dünya", o.dunya.isEmpty() ? "-" : o.dunya);
        satir(s, "Bölge", o.bolgeVar ? o.minX + "," + o.minY + "," + o.minZ + " → " + o.maxX + "," + o.maxY + "," + o.maxZ : "yok");
        satir(s, "Spawn1", o.spawn1 == null ? "yok" : o.spawn1.yazi());
        satir(s, "Spawn2", o.spawn2 == null ? "yok" : o.spawn2.yazi());
        satir(s, "Dış nokta", o.dis == null ? "yok" : o.dis.yazi());
        satir(s, "Kapı camı", String.valueOf(o.kapilar.size()));
        satir(s, "Maç süresi", plugin.yonetici().macSureMs(o) / 60_000L + " dk" + (o.macDakika == null ? " (varsayılan)" : ""));
        satir(s, "Eşya düşme", (plugin.yonetici().esyaDusuyor(o) ? "evet" : "hayır") + (o.esyaDusme == null ? " (varsayılan)" : ""));
        StringBuilder oy = new StringBuilder();
        for (UUID u : plugin.yonetici().odadakiler(o)) oy.append(plugin.yonetici().adGetir(u)).append(' ');
        satir(s, "İçerdekiler", oy.length() == 0 ? "-" : oy.toString().trim());
        satir(s, "Hazır mı", o.hazirMi() ? "evet" : "hayır (" + String.join(", ", o.eksikler()) + ")");
    }

    private void satir(CommandSender s, String anahtar, String deger) {
        s.sendMessage(plugin.m("bilgi-satir", "{anahtar}", anahtar, "{deger}", deger));
    }

    // ---------------- Tab ----------------

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        List<String> sonuc = new ArrayList<>();
        String son = a[a.length - 1].toLowerCase(Locale.ROOT);
        if (a.length == 1) {
            List<String> hepsi = new ArrayList<>(List.of("menu", "istatistik", "top", "yardim"));
            if (s.hasPermission(ADMIN)) hepsi.addAll(ADMIN_ALT);
            for (String x : hepsi) if (x.startsWith(son)) sonuc.add(x);
        } else if (a.length == 2 && s.hasPermission(ADMIN) && ODA_ALT.contains(a[0].toLowerCase(Locale.ROOT))) {
            for (Oda o : plugin.odalar().tum()) if (o.ad.toLowerCase(Locale.ROOT).startsWith(son)) sonuc.add(o.ad);
        } else if (a.length == 2 && a[0].equalsIgnoreCase("istatistik")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(son)) sonuc.add(p.getName());
            }
        }
        return sonuc;
    }
}
