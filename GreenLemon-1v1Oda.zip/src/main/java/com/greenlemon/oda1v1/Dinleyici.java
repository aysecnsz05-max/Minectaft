package com.greenlemon.oda1v1;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.inventory.EquipmentSlot;

import java.util.UUID;

final class Dinleyici implements Listener {
    private static final String ADMIN = "greenlemon.oda.admin";
    private final OdaPlugin plugin;

    Dinleyici(OdaPlugin plugin) {
        this.plugin = plugin;
    }

    private Yonetici y() {
        return plugin.yonetici();
    }

    // ---------------- Balta + kapı ----------------

    @EventHandler(priority = EventPriority.HIGHEST)
    public void tikla(PlayerInteractEvent e) {
        if (e.getHand() != EquipmentSlot.HAND) return;
        Action a = e.getAction();
        if (a != Action.LEFT_CLICK_BLOCK && a != Action.RIGHT_CLICK_BLOCK) return;
        Block b = e.getClickedBlock();
        if (b == null) return;
        Player p = e.getPlayer();

        // Seçim baltası
        if (plugin.baltaMi(p.getInventory().getItemInMainHand())) {
            if (!p.hasPermission(ADMIN)) return;
            e.setCancelled(true);
            OdaPlugin.Secim s = plugin.secimler().computeIfAbsent(p.getUniqueId(), k -> new OdaPlugin.Secim());
            String konum = b.getX() + ", " + b.getY() + ", " + b.getZ();
            if (a == Action.LEFT_CLICK_BLOCK) {
                s.a = b.getLocation();
                p.sendMessage(plugin.m("secim-1", "{konum}", konum));
            } else {
                s.b = b.getLocation();
                p.sendMessage(plugin.m("secim-2", "{konum}", konum));
            }
            return;
        }

        // Kapı camına dokunma
        Oda o = plugin.odalar().kapidan(b);
        if (o == null) return;
        e.setCancelled(true);
        y().kapiTiklandi(p, o);
    }

    // ---------------- Oda menüsü ----------------

    @EventHandler
    public void menuTikla(org.bukkit.event.inventory.InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof OdaMenu menu)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        if (e.getRawSlot() == OdaMenu.YENILE_SLOT) menu.yenile();
    }

    @EventHandler
    public void menuSurukle(org.bukkit.event.inventory.InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof OdaMenu) e.setCancelled(true);
    }

    // ---------------- Hasar ----------------

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void hasar(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player kurban)) return;
        Oda o = y().oda(kurban);

        Player saldirgan = null;
        if (e instanceof EntityDamageByEntityEvent be) {
            Object d = be.getDamager();
            if (d instanceof Projectile pr && pr.getShooter() instanceof Player sp) saldirgan = sp;
            else if (d instanceof Player dp) saldirgan = dp;
        }

        if (o != null) {
            // Boşluğa düşme / /kill serbest (oyuncu takılı kalmasın)
            EntityDamageEvent.DamageCause neden = e.getCause();
            if (neden == EntityDamageEvent.DamageCause.VOID || neden == EntityDamageEvent.DamageCause.SUICIDE) return;
            if (o.durum != Oda.Durum.MAC) {
                e.setCancelled(true);
                return;
            }
            if (saldirgan != null && !saldirgan.equals(kurban) && !y().rakipMi(o, kurban, saldirgan)) {
                e.setCancelled(true);
            }
            return;
        }
        // Kurban oda dışında: oda içindeki biri ona vuramasın
        if (saldirgan != null && y().oda(saldirgan) != null) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void olum(PlayerDeathEvent e) {
        Player kurban = e.getEntity();
        if (y().oda(kurban) == null) return;
        y().olumIsle(kurban, e);
    }

    @EventHandler
    public void yenidenDog(PlayerRespawnEvent e) {
        Location l = y().respawnKonum(e.getPlayer().getUniqueId());
        if (l != null) e.setRespawnLocation(l);
    }

    // ---------------- Komutlar / ışınlanma / hareket ----------------

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void komut(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!y().komutEngelli(p)) return;
        if (p.hasPermission("greenlemon.oda.bypass")) return;
        if (y().komutYasakMi(e.getMessage())) {
            e.setCancelled(true);
            p.sendMessage(plugin.m("komut-engel"));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void isinlan(PlayerTeleportEvent e) {
        if (!plugin.getConfig().getBoolean("mac.ender-engel", true)) return;
        Oda o = y().oda(e.getPlayer());
        if (o == null) return;
        if (o.durum != Oda.Durum.GERI_SAYIM && o.durum != Oda.Durum.MAC) return;
        PlayerTeleportEvent.TeleportCause c = e.getCause();
        if (c == PlayerTeleportEvent.TeleportCause.ENDER_PEARL
                || c == PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT
                || c == PlayerTeleportEvent.TeleportCause.COMMAND) {
            e.setCancelled(true);
        }
    }

    // Geri sayımda oyuncular yerinde donar (bakış serbest)
    @EventHandler(ignoreCancelled = true)
    public void hareket(PlayerMoveEvent e) {
        Location f = e.getFrom();
        Location t = e.getTo();
        if (t == null) return;
        if (f.getX() == t.getX() && f.getY() == t.getY() && f.getZ() == t.getZ()) return;
        Oda o = y().oda(e.getPlayer());
        if (o == null || o.durum != Oda.Durum.GERI_SAYIM) return;
        Location n = f.clone();
        n.setYaw(t.getYaw());
        n.setPitch(t.getPitch());
        e.setTo(n);
    }

    // ---------------- Giriş / çıkış ----------------

    @EventHandler
    public void cikis(PlayerQuitEvent e) {
        y().oyuncuAyrildi(e.getPlayer());
    }

    // Odada kapanan oyuncu geri girince spawn'a gönderilir
    @EventHandler
    public void giris(PlayerJoinEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Player p = Bukkit.getPlayer(id);
            if (p == null || y().oda(p) != null || p.hasPermission(ADMIN)) return;
            if (plugin.odalar().bolgeden(p.getLocation()) != null) p.teleport(plugin.sunucuSpawn());
        }, 20L);
    }

    // ---------------- Bölge koruması ----------------

    private boolean korumaGerek(Player p, Block b) {
        if (p.hasPermission(ADMIN)) return false;
        if (plugin.odalar().kapidan(b) != null) return true;
        return plugin.getConfig().getBoolean("bolge-koruma", true) && plugin.odalar().bolgeden(b.getLocation()) != null;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void blokKir(BlockBreakEvent e) {
        if (korumaGerek(e.getPlayer(), e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void blokKoy(BlockPlaceEvent e) {
        if (korumaGerek(e.getPlayer(), e.getBlock())) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void kova(PlayerBucketEmptyEvent e) {
        if (korumaGerek(e.getPlayer(), e.getBlock())) e.setCancelled(true);
    }
}
