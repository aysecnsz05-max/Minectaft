GreenLemon Duello - menülü, kitli, round'lu, dereceli düello sistemi
Hedef: Paper 1.20.1 (Java 17+)  |  Bağımlılık: yok
(Cam kapılı 1v1 ODALARI ayrı plugindir: GreenLemon-1v1Oda. İkisi birlikte sorunsuz çalışır.)

JAR NASIL OLUR? (3 yoldan biri)
1) JDK 17 + Maven: bu klasörde  mvn package  -> target/GreenLemon-Duello-1.0.0.jar -> plugins/
2) GitHub: zip'leri repoya yükle + build.yml (workflow) ekle, Actions derler.
3) IntelliJ IDEA: pom.xml'i Maven projesi olarak aç, Maven > package.

KURULUM (yetkili: greenlemon.duello.admin)
 /duello admin arena olustur arena1
 Arenada 1. oyuncunun duracağı yerde:  /duello admin arena spawn1 arena1
 Arenada 2. oyuncunun duracağı yerde:  /duello admin arena spawn2 arena1
 (isteğe bağlı) izleyici noktası:       /duello admin arena izle arena1
 (isteğe bağlı) sınırlar, iki köşede:   /duello admin arena bolge1 arena1   ve   /duello admin arena bolge2 arena1
 /duello admin arena bilgi arena1  ile kontrol et. İstediğin kadar arena aç; boş olan rastgele seçilir.

OYUNCU AKIŞI
 /duello  -> ANA MENÜ: Düello At | Dereceli Sıra | Maç İzle | Sıralama | İstatistik | Davet aç/kapat
 /duello <oyuncu>  veya menüden bir oyuncu seç -> AYAR MENÜSÜ:
    - Kit: "Kendi Eşyalarım" veya hazır kitler (Klasik, NoDebuff, Okçu) - sol/sağ tıkla değiştir
    - Arena: Rastgele ya da belirli arena
    - EŞYA DÜŞME: düşer / düşmez  (sadece "Kendi Eşyalarım" kitinde ve 1 round'luk maçta seçilebilir)
    - Round: 1 / 3 / 5 (best-of)
    - Daveti Gönder
 Rakibe tıklanabilir davet mesajı gider: [KABUL ET] [REDDET] [İNCELE].
 EŞYA DÜŞEN düelloda hızlı kabul kapalıdır: rakip ayarları menüden görüp (kırmızı uyarıyla) onaylamak zorundadır.

DÜELLO NASIL İŞLER
 - İkisi de arenaya ışınlanır, geri sayım (5 sn, donarlar), dövüş başlar. Her round'un süre sınırı var:
   dolunca canı fazla olan round'u alır.
 - Kit modunda herkes aynı kitle başlar; envanterin diske yedeklenir, maç bitince aynen geri gelir.
   (Sunucu çökse bile oyuncu girince eşyaları ve konumu geri verilir.)
 - Ölüm yoktur: öldürücü vuruş "round kaybı" sayılır (totem varsa vanilla çalışır), ölüm ekranı görmezsin.
   Tek istisna: "EŞYALAR DÜŞER" seçilmiş tek round'luk maçın karar vuruşu gerçek ölümdür:
   kaybeden eşyalarını kaybeder, kazanan 15 sn içinde toplar, kaybeden eski yerine döner.
 - Eşyalar KORUNUYOR seçiliyse (varsayılan) kimse eşya kaybetmez, maç sonunda herkes eski konumuna döner.
 - Maç sırasında /spawn /hub /warp /tp vb. engelli, ender pearl isteğe bağlı, arena dışına çıkan geri alınır.
 - Biri çıkarsa rakip kazanır; eşyalar ve konum çıkmadan önce iade edilir.

DERECELİ SIRA (ELO)
 /duello sira <kit> veya menü: sıraya gir, otomatik rakip bulunur; sadece kitlerle oynanır, eşya düşmez.
 ELO standart formülle değişir (k=32, başlangıç 1000). /duello top, /duello stat [oyuncu], menüde Sıralama.

İZLEME
 /duello izle <oyuncu> veya menüden maç seç -> arena izleyici noktasına geçersin (spectator).
 Çıkmak için /duello cik. Çökme olsa bile izleyici durumu yedeklenir.

KİTLER
 config.yml > kitler bölümünden istediğin kadar kit ekle/değiştir:
   - {slot: 0, tur: DIAMOND_SWORD, buyu: ["sharpness:2"]}
   - slot: 0-35 veya kask, gogus, pantolon, bot, offhand (slot bir liste de olabilir)
   - iksir: INSTANT_HEAL, guclu: true, adet, ad, kirilmaz
 Değişiklikten sonra /duello admin reload

KOMUTLAR
 Oyuncu: /duello [oyuncu|kabul|red|gelen|izle|cik|sira|top|stat|davetler ac|kapat|yardim]  (takma: /duel)
 Yetkili: /duello admin arena <olustur|sil|spawn1|spawn2|izle|bolge1|bolge2|aktif|pasif|bilgi|liste> [ad]
          /duello admin iptal <oyuncu> | elosifirla <oyuncu> | reload
 İzinler: greenlemon.duello.kullan (herkes), .izle (herkes), .admin (op), .bypass (maçta komut engelini yok sayar)

BLOK KOYMA
 Varsayılan: arenada blok koyma/kırma kapalı. Açmak istersen config'te kurallar.blok-koyma: true yap ve
 arenayı GreenLemon-BolgeTemizle ile bir bölge olarak tanımla (koyulan bloklar otomatik silinir).

DÜRÜST NOTLAR
 - Derlenip canlı sunucuda test edilmedi. İki hesapla önce test sunucusunda dene (özellikle kit modu,
   eşya düşme, round geçişi, çıkış yapma, /duello izle).
 - Eşya düşme kapalıyken bile kendi eşyalarınla dövüşürsün: dayanıklılık/oku harcarsın (kendi eşyaların).
   Risk istemeyenler için kit seçeneği var.
 - Başka eklenti ölümü iptal/değiştiriyorsa (ör. ölüm menüsü eklentileri) çakışabilir.
