package com.greenlemon.duello;

/** Bir düellonun seçenekleri (menüde seçilir). */
final class Ayar {
    static final String KENDI = "kendi";

    String kit = KENDI;
    String arena;          // null = rastgele
    boolean dusme;         // eşyalar düşsün mü
    int round = 1;         // 1, 3, 5
    boolean dereceli;      // ELO etkilenir mi

    boolean kitModu() {
        return !KENDI.equals(kit);
    }

    int gerekli() {
        return round / 2 + 1;
    }

    /** Tutarsız seçimleri düzeltir: eşya düşme sadece "kendi" kitinde, tek round'da ve derecesiz maçta olur. */
    void duzelt() {
        if (round != 1 && round != 3 && round != 5) round = 1;
        if (kitModu() || round > 1 || dereceli) dusme = false;
    }

    Ayar kopya() {
        Ayar a = new Ayar();
        a.kit = kit;
        a.arena = arena;
        a.dusme = dusme;
        a.round = round;
        a.dereceli = dereceli;
        return a;
    }
}
