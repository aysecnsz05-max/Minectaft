package com.greenlemon.duello;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

final class Arena {
    record Konum(String dunya, double x, double y, double z, float yaw, float pitch) {
        static Konum of(Location l) {
            return new Konum(l.getWorld().getName(), l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch());
        }

        Location al() {
            World w = Bukkit.getWorld(dunya);
            return w == null ? null : new Location(w, x, y, z, yaw, pitch);
        }

        String yazi() {
            return String.format("%.1f, %.1f, %.1f (%s)", x, y, z, dunya);
        }
    }

    final String ad;
    Konum spawn1;
    Konum spawn2;
    Konum izle;
    Konum c1;
    Konum c2;
    boolean aktif = true;

    /** Çalışma durumu: şu an bu arenada oynanan maç. */
    Mac mac;

    Arena(String ad) {
        this.ad = ad;
    }

    boolean hazirMi() {
        return spawn1 != null && spawn2 != null && spawn1.al() != null && spawn2.al() != null;
    }

    boolean bos() {
        return aktif && hazirMi() && mac == null;
    }

    /** Sınır tanımlıysa içeride mi; tanımlı değilse hep true. */
    boolean icerde(Location l) {
        if (c1 == null || c2 == null || l.getWorld() == null) return true;
        if (!l.getWorld().getName().equals(c1.dunya())) return false;
        double minX = Math.min(c1.x(), c2.x()), maxX = Math.max(c1.x(), c2.x()) + 1;
        double minY = Math.min(c1.y(), c2.y()), maxY = Math.max(c1.y(), c2.y()) + 1;
        double minZ = Math.min(c1.z(), c2.z()), maxZ = Math.max(c1.z(), c2.z()) + 1;
        return l.getX() >= minX && l.getX() <= maxX && l.getY() >= minY && l.getY() <= maxY
                && l.getZ() >= minZ && l.getZ() <= maxZ;
    }
}
