package com.greenlemon.duello;

import org.bukkit.ChatColor;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/** Renk ve metin yardımcıları. */
final class Yazi {
    private static final Pattern RENK = Pattern.compile("(?i)[&§][0-9A-FK-ORX]");

    private Yazi() {}

    static String renk(String s) {
        return ChatColor.translateAlternateColorCodes('&', s == null ? "" : s);
    }

    /** Oyuncudan gelen metindeki renk kodlarını ve satır sonlarını temizler. */
    static String temizle(String s) {
        if (s == null) return "";
        String t = s.replaceAll("[\\r\\n\\t]+", " ");
        return RENK.matcher(t).replaceAll("").trim();
    }

    /** Uzun metni lore için satırlara böler. */
    static List<String> sar(String metin, int genislik, String onek) {
        List<String> sonuc = new ArrayList<>();
        StringBuilder satir = new StringBuilder();
        for (String kelime : metin.split("\\s+")) {
            if (satir.length() > 0 && satir.length() + 1 + kelime.length() > genislik) {
                sonuc.add(renk(onek + satir));
                satir.setLength(0);
            }
            if (satir.length() > 0) satir.append(' ');
            satir.append(kelime);
        }
        if (satir.length() > 0) sonuc.add(renk(onek + satir));
        return sonuc;
    }
}
