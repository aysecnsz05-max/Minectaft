package com.greenlemon.duello;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Düello menüleri. */
final class Menuler {
    private Menuler() {}

    private static ItemStack kafa(OfflinePlayer sahip, String ad, List<String> lore) {
        ItemStack it = DuelloPlugin.esya(Material.PLAYER_HEAD, ad, lore);
        ItemMeta meta = it.getItemMeta();
        if (meta instanceof SkullMeta sm && sahip != null) {
            sm.setOwningPlayer(sahip);
            it.setItemMeta(sm);
        }
        return it;
    }

    private static List<String> eloSatirlari(Istatistik.Kayit k) {
        List<String> l = new ArrayList<>();
        if (k == null) {
            l.add("&7Henüz maç yok.");
            return l;
        }
        l.add("&6ELO: &f" + k.elo);
        l.add("&aGalibiyet: &f" + k.kazanma + " &8| &cMağlubiyet: &f" + k.kayip);
        l.add("&7Seri: &f" + k.seri + " &8(en iyi " + k.enIyiSeri + ")");
        return l;
    }

    // ================= Ana menü =================

    static final class Ana extends Menu {
        Ana(DuelloPlugin plugin) {
            super(plugin, 36, "&8GreenLemon | Düello");
        }

        @Override
        void doldur(Player p) {
            MacYonetici y = plugin.yonetici();
            koy(10, DuelloPlugin.esya(Material.DIAMOND_SWORD, "&a&lDüello At",
                    List.of("&7Bir oyuncu seç, kit/arena/round ve", "&7eşya düşme ayarlarını belirle.", "", "&eTıkla!")),
                    (pl, t) -> new OyuncuSec(plugin).ac(pl));

            String sirada = y.kuyrukKit(p.getUniqueId());
            if (sirada != null) {
                koy(12, DuelloPlugin.esya(Material.BARRIER, "&c&lSıradan Çık",
                        List.of("&7Şu an sıradasın: &f" + y.kitAdi(sirada), "", "&eTıkla!")),
                        (pl, t) -> {
                            y.cik(pl);
                            pl.closeInventory();
                        });
            } else {
                koy(12, DuelloPlugin.esya(Material.CLOCK, "&6&lDereceli Sıra",
                        List.of("&7Kit seç, otomatik rakip bul.", "&7Sonuç &6ELO&7'nu etkiler.", "", "&eTıkla!")),
                        (pl, t) -> new KitSec(plugin).ac(pl));
            }

            koy(14, DuelloPlugin.esya(Material.ENDER_EYE, "&b&lMaç İzle",
                    List.of("&7Süren maçları izle.", "&7Aktif maç: &f" + y.maclar().size(), "", "&eTıkla!")),
                    (pl, t) -> new AktifMaclar(plugin).ac(pl));

            koy(16, DuelloPlugin.esya(Material.GOLDEN_HELMET, "&e&lSıralama",
                    List.of("&7En yüksek ELO'lu oyuncular.", "", "&eTıkla!")),
                    (pl, t) -> new Siralama(plugin).ac(pl));

            List<String> lore = eloSatirlari(plugin.istatistik().bul(p.getUniqueId()));
            koy(21, kafa(p, "&6" + p.getName() + " &7- istatistiklerin", lore), null);

            boolean kapali = plugin.istatistik().davetKapali(p.getUniqueId());
            koy(23, DuelloPlugin.esya(kapali ? Material.RED_DYE : Material.LIME_DYE,
                    kapali ? "&cDüello davetleri: KAPALI" : "&aDüello davetleri: AÇIK",
                    List.of("&7Kapalıyken kimse sana davet atamaz.", "", "&eDeğiştirmek için tıkla!")),
                    (pl, t) -> {
                        plugin.istatistik().davetAyarla(pl.getUniqueId(), pl.getName(), !kapali);
                        pl.sendMessage(plugin.m(kapali ? "davetler-acildi" : "davetler-kapandi"));
                        yenile(pl);
                    });

            koy(31, DuelloPlugin.esya(Material.BARRIER, "&cKapat", List.of()), (pl, t) -> pl.closeInventory());
        }
    }

    // ================= Oyuncu seçimi =================

    static final class OyuncuSec extends Menu {
        private int sayfa;

        OyuncuSec(DuelloPlugin plugin) {
            super(plugin, 54, "&8Düello | Rakip seç");
        }

        @Override
        void doldur(Player p) {
            MacYonetici y = plugin.yonetici();
            List<Player> liste = new ArrayList<>();
            for (Player o : Bukkit.getOnlinePlayers()) {
                if (o.equals(p) || !y.musait(o.getUniqueId()) || plugin.istatistik().davetKapali(o.getUniqueId())) continue;
                liste.add(o);
            }
            int toplam = Math.max(1, (liste.size() + 44) / 45);
            if (sayfa >= toplam) sayfa = toplam - 1;
            if (sayfa < 0) sayfa = 0;
            for (int i = 0; i < 45; i++) {
                int idx = sayfa * 45 + i;
                if (idx >= liste.size()) break;
                Player o = liste.get(idx);
                UUID oid = o.getUniqueId();
                List<String> lore = new ArrayList<>(eloSatirlari(plugin.istatistik().bul(oid)));
                lore.add("");
                lore.add("&eTıkla: düello ayarlarını aç");
                koy(i, kafa(o, "&a" + o.getName(), lore), (pl, t) -> {
                    Player hedef = Bukkit.getPlayer(oid);
                    if (hedef == null) {
                        pl.sendMessage(plugin.m("oyuncu-yok"));
                        yenile(pl);
                        return;
                    }
                    new Ayar_(plugin, oid).ac(pl);
                });
            }
            if (liste.isEmpty()) {
                koy(22, DuelloPlugin.esya(Material.BARRIER, "&cMüsait oyuncu yok",
                        List.of("&7Herkes meşgul ya da davetleri kapalı.")), null);
            }
            if (sayfa > 0) koy(45, DuelloPlugin.esya(Material.ARROW, "&e« Önceki", List.of()), (pl, t) -> {
                sayfa--;
                yenile(pl);
            });
            if (sayfa < toplam - 1) koy(53, DuelloPlugin.esya(Material.ARROW, "&eSonraki »", List.of()), (pl, t) -> {
                sayfa++;
                yenile(pl);
            });
            koy(49, DuelloPlugin.esya(Material.BOOK, "&7Geri", List.of("&8Sayfa " + (sayfa + 1) + "/" + toplam)),
                    (pl, t) -> new Ana(plugin).ac(pl));
        }
    }

    // ================= Düello ayar menüsü =================

    /** Menü adı "Ayar" Ayar sınıfıyla karışmasın diye Ayar_. */
    static final class Ayar_ extends Menu {
        private final UUID hedef;
        private final Ayar ayar = new Ayar();
        private final List<String> kitler = new ArrayList<>();
        private final List<String> arenalar = new ArrayList<>();

        Ayar_(DuelloPlugin plugin, UUID hedef) {
            super(plugin, 36, "&8Düello | Ayarlar");
            this.hedef = hedef;
            kitler.add(Ayar.KENDI);
            for (Kit k : plugin.kitler().tum()) kitler.add(k.id);
            arenalar.add(null);
            for (Arena a : plugin.arenalar().tum()) if (a.aktif && a.hazirMi()) arenalar.add(a.ad);

            String vk = plugin.getConfig().getString("varsayilan.kit", Ayar.KENDI).toLowerCase();
            ayar.kit = kitler.contains(vk) ? vk : Ayar.KENDI;
            ayar.round = plugin.getConfig().getInt("varsayilan.round", 1);
            ayar.dusme = plugin.getConfig().getBoolean("varsayilan.dusme", false);
            ayar.duzelt();
        }

        private static <T> int sonraki(List<T> l, int idx, boolean ileri) {
            int n = l.size();
            return ileri ? (idx + 1) % n : (idx - 1 + n) % n;
        }

        @Override
        void doldur(Player p) {
            OfflinePlayer hedefOyuncu = Bukkit.getOfflinePlayer(hedef);
            String hedefAd = hedefOyuncu.getName() == null ? "?" : hedefOyuncu.getName();
            koy(4, kafa(hedefOyuncu, "&e" + hedefAd, eloSatirlari(plugin.istatistik().bul(hedef))), null);

            // Kit
            Material ikon;
            List<String> kitLore = new ArrayList<>();
            if (ayar.kitModu()) {
                Kit k = plugin.kitler().al(ayar.kit);
                ikon = k != null ? k.ikon : Material.IRON_SWORD;
                if (k != null) for (String s : k.aciklama) kitLore.add(s);
            } else {
                ikon = Material.matchMaterial(plugin.getConfig().getString("kendi-esyalar.ikon", "CHEST"));
                if (ikon == null) ikon = Material.CHEST;
                for (String s : plugin.getConfig().getStringList("kendi-esyalar.aciklama")) kitLore.add(s);
            }
            kitLore.add("");
            for (String id : kitler) {
                boolean secili = id.equals(ayar.kit);
                kitLore.add((secili ? "&a▶ " : "&8  ") + plugin.yonetici().kitAdi(id));
            }
            kitLore.add("");
            kitLore.add("&eSol tık: sonraki &8| &eSağ tık: önceki");
            koy(10, DuelloPlugin.esya(ikon, "&b&lKit: " + plugin.yonetici().kitAdi(ayar.kit), kitLore), (pl, t) -> {
                int i = kitler.indexOf(ayar.kit);
                ayar.kit = kitler.get(sonraki(kitler, i, t != ClickType.RIGHT));
                ayar.duzelt();
                yenile(pl);
            });

            // Arena
            List<String> arenaLore = new ArrayList<>();
            for (String a : arenalar) {
                boolean secili = (a == null && ayar.arena == null) || (a != null && a.equals(ayar.arena));
                arenaLore.add((secili ? "&a▶ " : "&8  ") + (a == null ? "Rastgele" : a));
            }
            arenaLore.add("");
            arenaLore.add("&eSol tık: sonraki &8| &eSağ tık: önceki");
            koy(12, DuelloPlugin.esya(Material.GRASS_BLOCK, "&a&lArena: " + (ayar.arena == null ? "Rastgele" : ayar.arena), arenaLore),
                    (pl, t) -> {
                        int i = arenalar.indexOf(ayar.arena);
                        ayar.arena = arenalar.get(sonraki(arenalar, i, t != ClickType.RIGHT));
                        yenile(pl);
                    });

            // Eşya düşme
            boolean izinli = !ayar.kitModu() && ayar.round == 1;
            if (!izinli) {
                koy(14, DuelloPlugin.esya(Material.GRAY_DYE, "&7&lEşya düşme: KAPALI",
                        List.of("&7Bu seçenek sadece &f'Kendi Eşyalarım' &7kitinde", "&7ve &f1 round&7'luk maçta kullanılabilir.")), null);
            } else {
                koy(14, DuelloPlugin.esya(ayar.dusme ? Material.RED_DYE : Material.LIME_DYE,
                        ayar.dusme ? "&c&lEŞYALAR DÜŞER" : "&a&lEşyalar korunur",
                        ayar.dusme
                                ? List.of("&cKaybeden TÜM eşyalarını kaybeder,", "&cdüşen eşyaları kazanan alır!", "", "&eDeğiştirmek için tıkla")
                                : List.of("&7Kimse eşya kaybetmez.", "", "&eDeğiştirmek için tıkla")),
                        (pl, t) -> {
                            ayar.dusme = !ayar.dusme;
                            yenile(pl);
                        });
            }

            // Round
            koy(16, DuelloPlugin.esya(Material.GOLDEN_SWORD, "&e&lRound: " + ayar.round,
                    List.of("&7Kazanılması gereken round: &f" + ayar.gerekli(), "", "&8(1 → 3 → 5)", "&eDeğiştirmek için tıkla")),
                    (pl, t) -> {
                        ayar.round = ayar.round == 1 ? 3 : ayar.round == 3 ? 5 : 1;
                        ayar.duzelt();
                        yenile(pl);
                    });

            // Gönder / iptal
            List<String> ozet = new ArrayList<>();
            ozet.add("&7Rakip: &f" + hedefAd);
            ozet.add("&7Kit: &f" + plugin.yonetici().kitAdi(ayar.kit));
            ozet.add("&7Round: &f" + ayar.round);
            ozet.add(ayar.dusme ? "&c⚠ Eşyalar düşer!" : "&7Eşyalar: &aKorunur");
            ozet.add("");
            ozet.add("&eTıkla: daveti gönder");
            koy(30, DuelloPlugin.esya(Material.EMERALD_BLOCK, "&a&lDaveti Gönder", ozet), (pl, t) -> {
                Player h = Bukkit.getPlayer(hedef);
                if (h == null) {
                    pl.sendMessage(plugin.m("oyuncu-yok"));
                    pl.closeInventory();
                    return;
                }
                pl.closeInventory();
                plugin.yonetici().davetGonder(pl, h, ayar);
            });
            koy(32, DuelloPlugin.esya(Material.BARRIER, "&c&lİptal", List.of()), (pl, t) -> pl.closeInventory());
        }
    }

    // ================= Gelen davet =================

    static final class Gelen extends Menu {
        Gelen(DuelloPlugin plugin) {
            super(plugin, 27, "&8Düello | Gelen davet");
        }

        @Override
        void doldur(Player p) {
            MacYonetici.Davet d = plugin.yonetici().gelenDavet(p.getUniqueId());
            if (d == null) {
                koy(13, DuelloPlugin.esya(Material.BARRIER, "&cBekleyen davet yok", List.of()), null);
                return;
            }
            Ayar a = d.ayar;
            OfflinePlayer g = Bukkit.getOfflinePlayer(d.gonderen);
            String gAd = g.getName() == null ? "?" : g.getName();
            koy(4, kafa(g, "&e" + gAd, eloSatirlari(plugin.istatistik().bul(d.gonderen))), null);

            List<String> lore = new ArrayList<>();
            lore.add("&7Kit: &f" + plugin.yonetici().kitAdi(a.kit));
            lore.add("&7Arena: &f" + (a.arena == null ? "Rastgele" : a.arena));
            lore.add("&7Round: &f" + a.round + " &8(kazanılması gereken " + a.gerekli() + ")");
            if (a.dusme) {
                lore.add("");
                lore.add("&c&lEŞYALAR DÜŞER!");
                lore.add("&cKaybeden eşyalarını kaybeder!");
            } else {
                lore.add("&7Eşyalar: &aKorunur");
            }
            koy(13, DuelloPlugin.esya(Material.PAPER, "&f&lDüello ayarları", lore), null);

            koy(11, DuelloPlugin.esya(Material.LIME_CONCRETE, "&a&lKABUL ET", List.of("&7Düelloyu kabul et")), (pl, t) -> {
                pl.closeInventory();
                plugin.yonetici().davetKabul(pl, true);
            });
            koy(15, DuelloPlugin.esya(Material.RED_CONCRETE, "&c&lREDDET", List.of("&7Daveti reddet")), (pl, t) -> {
                pl.closeInventory();
                plugin.yonetici().davetReddet(pl);
            });
        }
    }

    // ================= Aktif maçlar =================

    static final class AktifMaclar extends Menu {
        AktifMaclar(DuelloPlugin plugin) {
            super(plugin, 54, "&8Düello | Aktif maçlar");
        }

        @Override
        void doldur(Player p) {
            int i = 0;
            for (Mac m : plugin.yonetici().maclar()) {
                if (i >= 45) break;
                OfflinePlayer a = Bukkit.getOfflinePlayer(m.a);
                String an = a.getName() == null ? "?" : a.getName();
                OfflinePlayer b = Bukkit.getOfflinePlayer(m.b);
                String bn = b.getName() == null ? "?" : b.getName();
                List<String> lore = new ArrayList<>();
                lore.add("&7Kit: &f" + plugin.yonetici().kitAdi(m.ayar.kit));
                lore.add("&7Arena: &f" + m.arena.ad);
                lore.add("&7Round: &f" + m.round + " &8| &7Skor: &f" + m.skorYazi());
                lore.add("&7İzleyici: &f" + m.izleyiciler.size());
                lore.add("");
                lore.add("&eTıkla: izle");
                final Mac mac = m;
                koy(i++, kafa(a, "&c" + an + " &7vs &9" + bn, lore), (pl, t) -> {
                    pl.closeInventory();
                    plugin.yonetici().izle(pl, mac);
                });
            }
            if (i == 0) koy(22, DuelloPlugin.esya(Material.BARRIER, "&cAktif maç yok", List.of()), null);
            koy(49, DuelloPlugin.esya(Material.BOOK, "&7Geri", List.of()), (pl, t) -> new Ana(plugin).ac(pl));
        }
    }

    // ================= Sıralama =================

    static final class Siralama extends Menu {
        private static final int[] SLOTLAR = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21};

        Siralama(DuelloPlugin plugin) {
            super(plugin, 36, "&8Düello | ELO Sıralaması");
        }

        @Override
        void doldur(Player p) {
            List<Istatistik.Kayit> top = plugin.istatistik().top(SLOTLAR.length);
            for (int i = 0; i < top.size(); i++) {
                Istatistik.Kayit k = top.get(i);
                OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(k.ad);
                koy(SLOTLAR[i], kafa(op, "&e#" + (i + 1) + " &f" + k.ad, eloSatirlari(k)), null);
            }
            if (top.isEmpty()) koy(22, DuelloPlugin.esya(Material.BARRIER, "&cHenüz sıralama yok", List.of()), null);
            koy(31, DuelloPlugin.esya(Material.BOOK, "&7Geri", List.of()), (pl, t) -> new Ana(plugin).ac(pl));
        }
    }

    // ================= Kit seçimi (sıra için) =================

    static final class KitSec extends Menu {
        KitSec(DuelloPlugin plugin) {
            super(plugin, 27, "&8Düello | Sıra için kit seç");
        }

        @Override
        void doldur(Player p) {
            int slot = 10;
            for (Kit k : plugin.kitler().tum()) {
                if (slot > 16) break;
                List<String> lore = new ArrayList<>(k.aciklama);
                lore.add("");
                lore.add("&eTıkla: sıraya gir");
                final String id = k.id;
                koy(slot++, DuelloPlugin.esya(k.ikon, "&b&l" + k.ad, lore), (pl, t) -> {
                    pl.closeInventory();
                    plugin.yonetici().kuyrugaGir(pl, id);
                });
            }
            koy(22, DuelloPlugin.esya(Material.BOOK, "&7Geri", List.of()), (pl, t) -> new Ana(plugin).ac(pl));
        }
    }
}
