package com.greenlemon.duello;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;

import java.util.UUID;

final class Dinleyici implements Listener {
    private final DuelloPlugin plugin;

    Dinleyici(DuelloPlugin plugin) {
        this.plugin = plugin;
    }

    private MacYonetici y() {
        return plugin.yonetici();
    }

    // ---------------- Menüler ----------------

    @EventHandler
    public void menuTikla(InventoryClickEvent e) {
        if (!(e.getView().getTopInventory().getHolder() instanceof Menu menu)) return;
        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
        menu.tikla(p, e.getRawSlot(), e.getClick());
    }

    @EventHandler
    public void menuSurukle(InventoryDragEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Menu) e.setCancelled(true);
    }

    // ---------------- Hasar / ölüm ----------------

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void hasar(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player kurban)) return;
        Player saldirgan = null;
        if (e instanceof EntityDamageByEntityEvent be) {
            Object d = be.getDamager();
            if (d instanceof Projectile pr && pr.getShooter() instanceof Player sp) saldirgan = sp;
            else if (d instanceof Player dp) saldirgan = dp;
        }
        y().hasarIsle(e, kurban, saldirgan);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void olum(PlayerDeathEvent e) {
        y().olumIsle(e.getEntity(), e);
    }

    @EventHandler
    public void yenidenDog(PlayerRespawnEvent e) {
        Location l = y().respawnKonumu(e.getPlayer());
        if (l != null) e.setRespawnLocation(l);
    }

    // ---------------- Giriş / çıkış ----------------

    @EventHandler
    public void cikis(PlayerQuitEvent e) {
        y().oyuncuAyrildi(e.getPlayer());
    }

    @EventHandler
    public void giris(PlayerJoinEvent e) {
        UUID id = e.getPlayer().getUniqueId();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Player p = Bukkit.getPlayer(id);
            if (p != null) y().oyuncuGirdi(p);
        }, 10L);
    }

    // ---------------- Kısıtlamalar ----------------

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void komut(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (!y().komutEngelli(p) || p.hasPermission("greenlemon.duello.bypass")) return;
        if (y().komutYasakMi(e.getMessage())) {
            e.setCancelled(true);
            p.sendMessage(plugin.m("komut-engel"));
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void isinlan(PlayerTeleportEvent e) {
        Player p = e.getPlayer();
        PlayerTeleportEvent.TeleportCause c = e.getCause();
        if (y().izleyici(p)) {
            if (c == PlayerTeleportEvent.TeleportCause.SPECTATE || c == PlayerTeleportEvent.TeleportCause.COMMAND) {
                e.setCancelled(true);
            }
            return;
        }
        if (!y().katilimci(p)) return;
        if (c == PlayerTeleportEvent.TeleportCause.COMMAND || c == PlayerTeleportEvent.TeleportCause.CHORUS_FRUIT) {
            e.setCancelled(true);
        } else if (c == PlayerTeleportEvent.TeleportCause.ENDER_PEARL
                && !plugin.getConfig().getBoolean("kurallar.ender-inci", true)) {
            e.setCancelled(true);
        }
    }

    // Geri sayımda yerinde donar (bakış serbest)
    @EventHandler(ignoreCancelled = true)
    public void hareket(PlayerMoveEvent e) {
        Location f = e.getFrom();
        Location t = e.getTo();
        if (t == null) return;
        if (f.getX() == t.getX() && f.getY() == t.getY() && f.getZ() == t.getZ()) return;
        Mac m = y().macOf(e.getPlayer().getUniqueId());
        if (m == null || m.faz != Mac.Faz.GERI_SAYIM) return;
        Location n = f.clone();
        n.setYaw(t.getYaw());
        n.setPitch(t.getPitch());
        e.setTo(n);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void blokKir(BlockBreakEvent e) {
        if (y().katilimci(e.getPlayer()) && !plugin.getConfig().getBoolean("kurallar.blok-koyma", false)) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void blokKoy(BlockPlaceEvent e) {
        if (y().katilimci(e.getPlayer()) && !plugin.getConfig().getBoolean("kurallar.blok-koyma", false)) e.setCancelled(true);
    }

    // Kit modunda eşya atma/alma yok (arena çöplüğe dönmesin)
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void esyaAt(PlayerDropItemEvent e) {
        Mac m = y().macOf(e.getPlayer().getUniqueId());
        if (m != null && m.ayar.kitModu()) e.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void esyaAl(EntityPickupItemEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        Mac m = y().macOf(p.getUniqueId());
        if (m != null && m.ayar.kitModu()) e.setCancelled(true);
    }
}
