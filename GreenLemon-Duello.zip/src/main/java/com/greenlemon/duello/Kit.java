package com.greenlemon.duello;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

import java.util.List;

final class Kit {
    final String id;
    final String ad;
    final Material ikon;
    final List<String> aciklama;
    final ItemStack[] depo = new ItemStack[36];
    final ItemStack[] zirh = new ItemStack[4]; // bot, pantolon, göğüs, kask
    ItemStack offhand;

    Kit(String id, String ad, Material ikon, List<String> aciklama) {
        this.id = id;
        this.ad = ad;
        this.ikon = ikon;
        this.aciklama = aciklama;
    }

    /** Oyuncunun envanterini temizler ve kiti verir. */
    void ver(Player p) {
        PlayerInventory inv = p.getInventory();
        inv.clear();
        ItemStack[] d = new ItemStack[36];
        for (int i = 0; i < 36; i++) d[i] = depo[i] == null ? null : depo[i].clone();
        ItemStack[] z = new ItemStack[4];
        for (int i = 0; i < 4; i++) z[i] = zirh[i] == null ? null : zirh[i].clone();
        inv.setStorageContents(d);
        inv.setArmorContents(z);
        inv.setItemInOffHand(offhand == null ? new ItemStack(Material.AIR) : offhand.clone());
        inv.setHeldItemSlot(0);
    }
}
