package com.greenlemon.duello;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.regex.Pattern;

final class Komutlar implements TabExecutor {
    private static final Pattern ISIM = Pattern.compile("^[A-Za-z0-9_-]{2,20}$");
    private static final List<String> ALT = List.of("kabul", "red", "gelen", "izle", "cik", "sira", "top", "stat",
            "davetler", "yardim", "admin");
    private static final List<String> ARENA_ALT = List.of("liste", "olustur", "sil", "spawn1", "spawn2", "izle",
            "bolge1", "bolge2", "aktif", "pasif", "bilgi");
    private static final List<String> ARENA_ADLI = List.of("sil", "spawn1", "spawn2", "izle", "bolge1", "bolge2",
            "aktif", "pasif", "bilgi");

    private final DuelloPlugin plugin;

    Komutlar(DuelloPlugin plugin) {
        this.plugin = plugin;
    }

    private MacYonetici y() {
        return plugin.yonetici();
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) {
            if (s instanceof Player p) {
                if (!kullanabilir(p)) return true;
                new Menuler.Ana(plugin).ac(p);
            } else {
                yardim(s);
            }
            return true;
        }
        String alt = a[0].toLowerCase(Locale.ROOT);
        if (alt.equals("admin")) {
            admin(s, a);
            return true;
        }
        if (alt.equals("yardim")) {
            yardim(s);
            return true;
        }
        if (alt.equals("top")) {
            top(s);
            return true;
        }
        if (alt.equals("stat") || alt.equals("istatistik")) {
            stat(s, a);
            return true;
        }
        if (!(s instanceof Player p)) {
            s.sendMessage(plugin.m("sadece-oyuncu"));
            return true;
        }
        if (!kullanabilir(p)) return true;

        switch (alt) {
            case "kabul" -> y().davetKabul(p, false);
            case "red" -> y().davetReddet(p);
            case "gelen" -> {
                if (y().gelenDavet(p.getUniqueId()) == null) p.sendMessage(plugin.m("davet-yok"));
                else new Menuler.Gelen(plugin).ac(p);
            }
            case "cik" -> y().cik(p);
            case "izle" -> izle(p, a);
            case "sira" -> sira(p, a);
            case "davetler" -> {
                String v = a.length > 1 ? a[1].toLowerCase(Locale.ROOT) : "";
                if (v.equals("ac") || v.equals("kapat")) {
                    plugin.istatistik().davetAyarla(p.getUniqueId(), p.getName(), v.equals("kapat"));
                    p.sendMessage(plugin.m(v.equals("ac") ? "davetler-acildi" : "davetler-kapandi"));
                } else {
                    yardim(p);
                }
            }
            default -> {
                Player hedef = Bukkit.getPlayerExact(a[0]);
                if (hedef == null) {
                    p.sendMessage(plugin.m("oyuncu-yok"));
                } else if (hedef.equals(p)) {
                    p.sendMessage(plugin.m("kendine"));
                } else if (!y().musait(p.getUniqueId())) {
                    p.sendMessage(plugin.m("sen-mesgulsun"));
                } else {
                    new Menuler.Ayar_(plugin, hedef.getUniqueId()).ac(p);
                }
            }
        }
        return true;
    }

    private boolean kullanabilir(Player p) {
        if (p.hasPermission("greenlemon.duello.kullan")) return true;
        p.sendMessage(plugin.m("yetki-yok"));
        return false;
    }

    private void yardim(CommandSender s) {
        for (String l : plugin.mListe("yardim")) s.sendMessage(l);
    }

    private void izle(Player p, String[] a) {
        if (!p.hasPermission("greenlemon.duello.izle")) {
            p.sendMessage(plugin.m("yetki-yok"));
            return;
        }
        if (a.length < 2) {
            new Menuler.AktifMaclar(plugin).ac(p);
            return;
        }
        Player hedef = Bukkit.getPlayerExact(a[1]);
        Mac m = hedef == null ? null : y().macOf(hedef.getUniqueId());
        if (m == null) {
            p.sendMessage(plugin.m("izle-oyuncu-yok", "{oyuncu}", a[1]));
            return;
        }
        y().izle(p, m);
    }

    private void sira(Player p, String[] a) {
        if (a.length < 2) {
            StringBuilder sb = new StringBuilder();
            for (Kit k : plugin.kitler().tum()) sb.append(k.id).append(", ");
            String kitler = sb.length() > 2 ? sb.substring(0, sb.length() - 2) : "-";
            p.sendMessage(plugin.m("kuyruk-kit-gerekli", "{kitler}", kitler));
            return;
        }
        y().kuyrugaGir(p, a[1].toLowerCase(Locale.ROOT));
    }

    private void top(CommandSender s) {
        List<Istatistik.Kayit> l = plugin.istatistik().top(10);
        if (l.isEmpty()) {
            s.sendMessage(plugin.m("stat-yok"));
            return;
        }
        s.sendMessage(plugin.m("top-baslik"));
        int i = 1;
        for (Istatistik.Kayit k : l) {
            s.sendMessage(plugin.m("top-satir", "{sira}", String.valueOf(i++), "{oyuncu}", k.ad,
                    "{elo}", String.valueOf(k.elo), "{kazanma}", String.valueOf(k.kazanma), "{kayip}", String.valueOf(k.kayip)));
        }
    }

    private void stat(CommandSender s, String[] a) {
        Istatistik.Kayit k;
        if (a.length > 1) {
            k = plugin.istatistik().bulAd(a[1]);
        } else if (s instanceof Player p) {
            k = plugin.istatistik().bul(p.getUniqueId());
        } else {
            s.sendMessage(plugin.m("sadece-oyuncu"));
            return;
        }
        if (k == null) {
            s.sendMessage(plugin.m("stat-yok"));
            return;
        }
        s.sendMessage(plugin.m("stat-baslik", "{oyuncu}", k.ad));
        s.sendMessage(plugin.m("stat-satir", "{elo}", String.valueOf(k.elo), "{kazanma}", String.valueOf(k.kazanma),
                "{kayip}", String.valueOf(k.kayip), "{seri}", String.valueOf(k.seri), "{enIyi}", String.valueOf(k.enIyiSeri)));
    }

    // ---------------- Yönetici ----------------

    private void admin(CommandSender s, String[] a) {
        if (!s.hasPermission("greenlemon.duello.admin")) {
            s.sendMessage(plugin.m("yetki-yok"));
            return;
        }
        if (a.length < 2) {
            s.sendMessage(plugin.m("admin-kullanim"));
            return;
        }
        switch (a[1].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                plugin.yenidenYukle();
                s.sendMessage(plugin.m("yeniden-yuklendi", "{kit}", String.valueOf(plugin.kitler().sayi())));
            }
            case "arena" -> arena(s, a);
            case "iptal" -> {
                Player hedef = a.length > 2 ? Bukkit.getPlayerExact(a[2]) : null;
                Mac m = hedef == null ? null : y().macOf(hedef.getUniqueId());
                if (m == null) {
                    s.sendMessage(plugin.m("admin-iptal-yok"));
                    return;
                }
                y().macIptal(m);
            }
            case "elosifirla" -> {
                UUID id = a.length > 2 ? plugin.istatistik().uuidAd(a[2]) : null;
                if (id == null) {
                    s.sendMessage(plugin.m("stat-yok"));
                    return;
                }
                plugin.istatistik().eloSifirla(id);
                s.sendMessage(plugin.m("elo-sifirlandi", "{oyuncu}", a[2]));
            }
            default -> s.sendMessage(plugin.m("admin-kullanim"));
        }
    }

    private void arena(CommandSender s, String[] a) {
        if (a.length < 3) {
            s.sendMessage(plugin.m("admin-kullanim"));
            return;
        }
        String alt = a[2].toLowerCase(Locale.ROOT);
        if (alt.equals("liste")) {
            s.sendMessage(plugin.m("arena-liste-baslik"));
            for (Arena ar : plugin.arenalar().tum()) {
                s.sendMessage(plugin.m("arena-liste-satir", "{ad}", ar.ad, "{durum}", arenaDurum(ar),
                        "{hazir}", ar.hazirMi() ? "hazır" : "eksik: spawn1/spawn2"));
            }
            return;
        }
        if (a.length < 4) {
            s.sendMessage(plugin.m("admin-kullanim"));
            return;
        }
        String ad = a[3];
        if (alt.equals("olustur")) {
            if (!ISIM.matcher(ad).matches()) {
                s.sendMessage(plugin.m("arena-isim-gecersiz"));
                return;
            }
            if (plugin.arenalar().al(ad) != null) {
                s.sendMessage(plugin.m("arena-var"));
                return;
            }
            plugin.arenalar().ekle(new Arena(ad));
            plugin.arenalar().kaydet();
            s.sendMessage(plugin.m("arena-olusturuldu", "{ad}", ad));
            return;
        }
        Arena ar = plugin.arenalar().al(ad);
        if (ar == null) {
            s.sendMessage(plugin.m("arena-bulunamadi"));
            return;
        }
        switch (alt) {
            case "sil" -> {
                if (ar.mac != null) {
                    s.sendMessage(plugin.m("arena-mesgul"));
                    return;
                }
                plugin.arenalar().sil(ar);
                plugin.arenalar().kaydet();
                s.sendMessage(plugin.m("arena-silindi", "{ad}", ar.ad));
            }
            case "spawn1", "spawn2", "izle", "bolge1", "bolge2" -> {
                if (!(s instanceof Player p)) {
                    s.sendMessage(plugin.m("sadece-oyuncu"));
                    return;
                }
                boolean bolge = alt.startsWith("bolge");
                Arena.Konum k = Arena.Konum.of(bolge ? p.getLocation().getBlock().getLocation() : p.getLocation());
                switch (alt) {
                    case "spawn1" -> ar.spawn1 = k;
                    case "spawn2" -> ar.spawn2 = k;
                    case "izle" -> ar.izle = k;
                    case "bolge1" -> ar.c1 = k;
                    default -> ar.c2 = k;
                }
                plugin.arenalar().kaydet();
                s.sendMessage(plugin.m("arena-nokta", "{ad}", ar.ad, "{nokta}", alt));
            }
            case "aktif", "pasif" -> {
                ar.aktif = alt.equals("aktif");
                plugin.arenalar().kaydet();
                s.sendMessage(plugin.m("arena-durum", "{ad}", ar.ad, "{durum}", arenaDurum(ar)));
            }
            case "bilgi" -> {
                satir(s, "Durum", arenaDurum(ar));
                satir(s, "Spawn1", ar.spawn1 == null ? "yok" : ar.spawn1.yazi());
                satir(s, "Spawn2", ar.spawn2 == null ? "yok" : ar.spawn2.yazi());
                satir(s, "İzleyici noktası", ar.izle == null ? "yok" : ar.izle.yazi());
                satir(s, "Sınırlar", ar.c1 != null && ar.c2 != null ? "tanımlı" : "yok (sınır kontrolü kapalı)");
                satir(s, "Hazır", ar.hazirMi() ? "evet" : "hayır");
            }
            default -> s.sendMessage(plugin.m("admin-kullanim"));
        }
    }

    private String arenaDurum(Arena ar) {
        if (!ar.aktif) return "&cPasif";
        if (ar.mac != null) return "&6Maç sürüyor";
        return "&aBoş";
    }

    private void satir(CommandSender s, String anahtar, String deger) {
        s.sendMessage(plugin.m("arena-bilgi-satir", "{anahtar}", anahtar, "{deger}", deger));
    }

    // ---------------- Tab ----------------

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String alias, String[] a) {
        List<String> sonuc = new ArrayList<>();
        String son = a[a.length - 1].toLowerCase(Locale.ROOT);
        boolean admin = s.hasPermission("greenlemon.duello.admin");
        if (a.length == 1) {
            for (String x : ALT) if (x.startsWith(son) && (admin || !x.equals("admin"))) sonuc.add(x);
            oyuncular(sonuc, son);
        } else if (a.length == 2) {
            switch (a[0].toLowerCase(Locale.ROOT)) {
                case "izle", "stat" -> oyuncular(sonuc, son);
                case "sira" -> {
                    for (Kit k : plugin.kitler().tum()) if (k.id.startsWith(son)) sonuc.add(k.id);
                }
                case "davetler" -> {
                    for (String x : List.of("ac", "kapat")) if (x.startsWith(son)) sonuc.add(x);
                }
                case "admin" -> {
                    if (admin) for (String x : List.of("arena", "iptal", "elosifirla", "reload")) if (x.startsWith(son)) sonuc.add(x);
                }
                default -> { }
            }
        } else if (admin && a[0].equalsIgnoreCase("admin")) {
            if (a.length == 3 && a[1].equalsIgnoreCase("arena")) {
                for (String x : ARENA_ALT) if (x.startsWith(son)) sonuc.add(x);
            } else if (a.length == 4 && a[1].equalsIgnoreCase("arena") && ARENA_ADLI.contains(a[2].toLowerCase(Locale.ROOT))) {
                for (Arena ar : plugin.arenalar().tum()) if (ar.ad.toLowerCase(Locale.ROOT).startsWith(son)) sonuc.add(ar.ad);
            } else if (a.length == 3 && (a[1].equalsIgnoreCase("iptal") || a[1].equalsIgnoreCase("elosifirla"))) {
                oyuncular(sonuc, son);
            }
        }
        return sonuc;
    }

    private void oyuncular(List<String> hedef, String on) {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getName().toLowerCase(Locale.ROOT).startsWith(on)) hedef.add(p.getName());
        }
    }
}
