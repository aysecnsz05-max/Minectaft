package com.greenlemon.duello;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Arenaların depolanması (arenalar.yml). */
final class Arenalar {
    private final DuelloPlugin plugin;
    private final File dosya;
    private final Map<String, Arena> arenalar = new LinkedHashMap<>();

    Arenalar(DuelloPlugin plugin) {
        this.plugin = plugin;
        this.dosya = new File(plugin.getDataFolder(), "arenalar.yml");
    }

    Collection<Arena> tum() {
        return new ArrayList<>(arenalar.values());
    }

    Arena al(String ad) {
        return ad == null ? null : arenalar.get(ad.toLowerCase(Locale.ROOT));
    }

    void ekle(Arena a) {
        arenalar.put(a.ad.toLowerCase(Locale.ROOT), a);
    }

    void sil(Arena a) {
        arenalar.remove(a.ad.toLowerCase(Locale.ROOT));
    }

    void yukle() {
        arenalar.clear();
        if (!dosya.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dosya);
        ConfigurationSection kok = y.getConfigurationSection("arenalar");
        if (kok == null) return;
        for (String ad : kok.getKeys(false)) {
            ConfigurationSection s = kok.getConfigurationSection(ad);
            if (s == null) continue;
            Arena a = new Arena(ad);
            a.aktif = s.getBoolean("aktif", true);
            a.spawn1 = oku(s.getConfigurationSection("spawn1"));
            a.spawn2 = oku(s.getConfigurationSection("spawn2"));
            a.izle = oku(s.getConfigurationSection("izle"));
            a.c1 = oku(s.getConfigurationSection("c1"));
            a.c2 = oku(s.getConfigurationSection("c2"));
            arenalar.put(ad.toLowerCase(Locale.ROOT), a);
        }
    }

    void kaydet() {
        YamlConfiguration y = new YamlConfiguration();
        for (Arena a : arenalar.values()) {
            String p = "arenalar." + a.ad + ".";
            y.set(p + "aktif", a.aktif);
            yaz(y, p + "spawn1", a.spawn1);
            yaz(y, p + "spawn2", a.spawn2);
            yaz(y, p + "izle", a.izle);
            yaz(y, p + "c1", a.c1);
            yaz(y, p + "c2", a.c2);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(dosya);
        } catch (IOException e) {
            plugin.getLogger().severe("arenalar.yml kaydedilemedi: " + e.getMessage());
        }
    }

    private static Arena.Konum oku(ConfigurationSection s) {
        if (s == null || !s.contains("dunya")) return null;
        return new Arena.Konum(s.getString("dunya", ""), s.getDouble("x"), s.getDouble("y"), s.getDouble("z"),
                (float) s.getDouble("yaw"), (float) s.getDouble("pitch"));
    }

    private static void yaz(YamlConfiguration y, String yol, Arena.Konum k) {
        if (k == null) return;
        y.set(yol + ".dunya", k.dunya());
        y.set(yol + ".x", k.x());
        y.set(yol + ".y", k.y());
        y.set(yol + ".z", k.z());
        y.set(yol + ".yaw", (double) k.yaw());
        y.set(yol + ".pitch", (double) k.pitch());
    }
}
