package com.greenlemon.duello;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** ELO ve istatistikler + oyuncu ayarları (oyuncular.yml). Ana thread. */
final class Istatistik {
    static final class Kayit {
        String ad = "?";
        int elo;
        int kazanma;
        int kayip;
        int seri;
        int enIyiSeri;
        boolean davetKapali;
    }

    private final DuelloPlugin plugin;
    private final File dosya;
    private final Map<UUID, Kayit> kayitlar = new HashMap<>();

    Istatistik(DuelloPlugin plugin) {
        this.plugin = plugin;
        this.dosya = new File(plugin.getDataFolder(), "oyuncular.yml");
    }

    private int baslangicElo() {
        return plugin.getConfig().getInt("elo.baslangic", 1000);
    }

    void yukle() {
        kayitlar.clear();
        if (!dosya.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(dosya);
        ConfigurationSection kok = y.getConfigurationSection("oyuncular");
        if (kok == null) return;
        for (String anahtar : kok.getKeys(false)) {
            ConfigurationSection s = kok.getConfigurationSection(anahtar);
            if (s == null) continue;
            try {
                Kayit k = new Kayit();
                k.ad = s.getString("ad", "?");
                k.elo = s.getInt("elo", baslangicElo());
                k.kazanma = s.getInt("kazanma");
                k.kayip = s.getInt("kayip");
                k.seri = s.getInt("seri");
                k.enIyiSeri = s.getInt("en-iyi-seri");
                k.davetKapali = s.getBoolean("davet-kapali");
                kayitlar.put(UUID.fromString(anahtar), k);
            } catch (IllegalArgumentException ignored) {
                // bozuk uuid
            }
        }
    }

    Kayit getir(UUID id, String ad) {
        Kayit k = kayitlar.computeIfAbsent(id, x -> {
            Kayit n = new Kayit();
            n.elo = baslangicElo();
            return n;
        });
        if (ad != null) k.ad = ad;
        return k;
    }

    Kayit bul(UUID id) {
        return kayitlar.get(id);
    }

    Kayit bulAd(String ad) {
        for (Kayit k : kayitlar.values()) if (k.ad.equalsIgnoreCase(ad)) return k;
        return null;
    }

    UUID uuidAd(String ad) {
        for (Map.Entry<UUID, Kayit> e : kayitlar.entrySet()) if (e.getValue().ad.equalsIgnoreCase(ad)) return e.getKey();
        return null;
    }

    boolean davetKapali(UUID id) {
        Kayit k = kayitlar.get(id);
        return k != null && k.davetKapali;
    }

    void davetAyarla(UUID id, String ad, boolean kapali) {
        getir(id, ad).davetKapali = kapali;
        kaydet();
    }

    void kazanma(UUID id, String ad) {
        Kayit k = getir(id, ad);
        k.kazanma++;
        k.seri++;
        k.enIyiSeri = Math.max(k.enIyiSeri, k.seri);
        kaydet();
    }

    void kayip(UUID id, String ad) {
        Kayit k = getir(id, ad);
        k.kayip++;
        k.seri = 0;
        kaydet();
    }

    /** Standart ELO. Kazananın kazandığı puanı döner. */
    int eloGuncelle(UUID kazanan, UUID kaybeden) {
        Kayit kk = getir(kazanan, null);
        Kayit bb = getir(kaybeden, null);
        double beklenen = 1.0 / (1.0 + Math.pow(10.0, (bb.elo - kk.elo) / 400.0));
        int k = plugin.getConfig().getInt("elo.k", 32);
        int degisim = Math.max(1, (int) Math.round(k * (1.0 - beklenen)));
        kk.elo += degisim;
        bb.elo = Math.max(0, bb.elo - degisim);
        kaydet();
        return degisim;
    }

    void eloSifirla(UUID id) {
        Kayit k = kayitlar.get(id);
        if (k != null) {
            k.elo = baslangicElo();
            kaydet();
        }
    }

    List<Kayit> top(int n) {
        List<Kayit> l = new ArrayList<>(kayitlar.values());
        l.removeIf(k -> k.kazanma + k.kayip == 0);
        l.sort(Comparator.comparingInt((Kayit k) -> k.elo).reversed());
        return l.size() > n ? l.subList(0, n) : l;
    }

    void kaydet() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<UUID, Kayit> e : kayitlar.entrySet()) {
            String p = "oyuncular." + e.getKey() + ".";
            Kayit k = e.getValue();
            y.set(p + "ad", k.ad);
            y.set(p + "elo", k.elo);
            y.set(p + "kazanma", k.kazanma);
            y.set(p + "kayip", k.kayip);
            y.set(p + "seri", k.seri);
            y.set(p + "en-iyi-seri", k.enIyiSeri);
            y.set(p + "davet-kapali", k.davetKapali);
        }
        try {
            plugin.getDataFolder().mkdirs();
            y.save(dosya);
        } catch (IOException ex) {
            plugin.getLogger().severe("oyuncular.yml kaydedilemedi: " + ex.getMessage());
        }
    }
}
