package com.greenlemon.duello;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;

/** Tüm menülerin tabanı: slot başına tıklama aksiyonu. */
abstract class Menu implements InventoryHolder {
    protected final DuelloPlugin plugin;
    private final Inventory inv;
    private final Map<Integer, BiConsumer<Player, ClickType>> aksiyonlar = new HashMap<>();

    Menu(DuelloPlugin plugin, int boyut, String baslik) {
        this.plugin = plugin;
        this.inv = Bukkit.createInventory(this, boyut, Yazi.renk(baslik));
    }

    /** Menünün içeriğini doldurur (koy ile). */
    abstract void doldur(Player p);

    void ac(Player p) {
        yenile(p);
        p.openInventory(inv);
    }

    void yenile(Player p) {
        inv.clear();
        aksiyonlar.clear();
        ItemStack cam = DuelloPlugin.esya(Material.GRAY_STAINED_GLASS_PANE, " ", List.of());
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, cam);
        doldur(p);
    }

    protected void koy(int slot, ItemStack item, BiConsumer<Player, ClickType> aksiyon) {
        inv.setItem(slot, item);
        if (aksiyon != null) aksiyonlar.put(slot, aksiyon);
    }

    void tikla(Player p, int slot, ClickType tur) {
        BiConsumer<Player, ClickType> a = aksiyonlar.get(slot);
        if (a == null) return;
        plugin.ses(p, "menu", 1f);
        a.accept(p, tur);
    }

    @Override
    public Inventory getInventory() {
        return inv;
    }
}
