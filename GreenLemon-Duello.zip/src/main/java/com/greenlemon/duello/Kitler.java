package com.greenlemon.duello;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionData;
import org.bukkit.potion.PotionType;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** config.yml > kitler bölümünü okur. */
final class Kitler {
    private final DuelloPlugin plugin;
    private final Map<String, Kit> kitler = new LinkedHashMap<>();

    Kitler(DuelloPlugin plugin) {
        this.plugin = plugin;
    }

    Collection<Kit> tum() {
        return new ArrayList<>(kitler.values());
    }

    Kit al(String id) {
        return id == null ? null : kitler.get(id.toLowerCase(Locale.ROOT));
    }

    int sayi() {
        return kitler.size();
    }

    void yukle() {
        kitler.clear();
        ConfigurationSection kok = plugin.getConfig().getConfigurationSection("kitler");
        if (kok == null) return;
        for (String id : kok.getKeys(false)) {
            ConfigurationSection s = kok.getConfigurationSection(id);
            if (s == null) continue;
            Material ikon = Material.matchMaterial(s.getString("ikon", "IRON_SWORD"));
            if (ikon == null) ikon = Material.IRON_SWORD;
            Kit k = new Kit(id.toLowerCase(Locale.ROOT), s.getString("ad", id), ikon, s.getStringList("aciklama"));
            for (Map<?, ?> m : s.getMapList("esyalar")) {
                try {
                    esyaEkle(k, m);
                } catch (Exception e) {
                    plugin.getLogger().warning("Kit '" + id + "' eşya hatası: " + e.getMessage());
                }
            }
            kitler.put(k.id, k);
        }
    }

    private void esyaEkle(Kit k, Map<?, ?> m) {
        Object tur = m.get("tur");
        Material mat = tur == null ? null : Material.matchMaterial(String.valueOf(tur));
        if (mat == null) throw new IllegalArgumentException("bilinmeyen eşya: " + tur);

        Object adetObj = m.get("adet");
        int adet = adetObj instanceof Number n ? n.intValue() : 1;
        ItemStack it = new ItemStack(mat, Math.max(1, adet));
        ItemMeta meta = it.getItemMeta();

        if (m.get("ad") != null) meta.setDisplayName(Yazi.renk(String.valueOf(m.get("ad"))));
        if (Boolean.TRUE.equals(m.get("kirilmaz"))) meta.setUnbreakable(true);

        Object buyu = m.get("buyu");
        if (buyu instanceof List<?> l) {
            for (Object o : l) {
                String[] p = String.valueOf(o).split(":");
                Enchantment e = buyuBul(p[0].trim());
                if (e == null) throw new IllegalArgumentException("bilinmeyen büyü: " + o);
                int seviye = p.length > 1 ? Integer.parseInt(p[1].trim()) : 1;
                meta.addEnchant(e, seviye, true);
            }
        }
        if (meta instanceof PotionMeta pm && m.get("iksir") != null) {
            PotionType t = PotionType.valueOf(String.valueOf(m.get("iksir")).toUpperCase(Locale.ROOT));
            pm.setBasePotionData(new PotionData(t, Boolean.TRUE.equals(m.get("uzun")), Boolean.TRUE.equals(m.get("guclu"))));
        }
        it.setItemMeta(meta);

        Object slot = m.get("slot");
        List<Object> slotlar = new ArrayList<>();
        if (slot instanceof List<?> sl) slotlar.addAll(sl);
        else if (slot != null) slotlar.add(slot);
        if (slotlar.isEmpty()) throw new IllegalArgumentException("slot yok: " + tur);
        for (Object s : slotlar) yerlestir(k, it, String.valueOf(s).toLowerCase(Locale.ROOT));
    }

    private void yerlestir(Kit k, ItemStack it, String slot) {
        switch (slot) {
            case "bot", "boots" -> k.zirh[0] = it.clone();
            case "pantolon", "leggings" -> k.zirh[1] = it.clone();
            case "gogus", "chestplate" -> k.zirh[2] = it.clone();
            case "kask", "helmet" -> k.zirh[3] = it.clone();
            case "offhand", "sol" -> k.offhand = it.clone();
            default -> {
                int i = Integer.parseInt(slot);
                if (i < 0 || i > 35) throw new IllegalArgumentException("slot 0-35 olmalı: " + slot);
                k.depo[i] = it.clone();
            }
        }
    }

    private static Enchantment buyuBul(String ad) {
        Enchantment e = Enchantment.getByKey(NamespacedKey.minecraft(ad.toLowerCase(Locale.ROOT)));
        if (e == null) e = Enchantment.getByName(ad.toUpperCase(Locale.ROOT));
        return e;
    }
}
