package com.greenlemon.duello;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.potion.PotionEffect;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.UUID;

/**
 * Düello öncesi oyuncu durumu (konum, mod, can, envanter). Kit modunda envanter da yedeklenir.
 * Sunucu çökerse eşyalar kaybolmasın diye diske yazılır; oyuncu girince geri verilir.
 */
final class Yedek {
    static File klasor;

    Location konum;
    GameMode mod = GameMode.SURVIVAL;
    double can = 20;
    int yemek = 20;
    float doygunluk = 20f;
    ItemStack[] envanter; // null: envanter yedeklenmedi. Düzen: 0-35 depo, 36-39 zırh (bot..kask), 40 offhand

    static Yedek al(Player p, boolean envanterDahil) {
        Yedek y = new Yedek();
        y.konum = p.getLocation().clone();
        y.mod = p.getGameMode();
        y.can = p.getHealth();
        y.yemek = p.getFoodLevel();
        y.doygunluk = p.getSaturation();
        if (envanterDahil) {
            PlayerInventory inv = p.getInventory();
            ItemStack[] hepsi = new ItemStack[41];
            ItemStack[] depo = inv.getStorageContents();
            for (int i = 0; i < 36 && i < depo.length; i++) hepsi[i] = depo[i];
            ItemStack[] zirh = inv.getArmorContents();
            for (int i = 0; i < 4 && i < zirh.length; i++) hepsi[36 + i] = zirh[i];
            hepsi[40] = inv.getItemInOffHand();
            y.envanter = hepsi;
        }
        return y;
    }

    /** Durumu oyuncuya uygular (ışınlamaz). */
    void uygula(Player p, boolean canDoldur) {
        for (PotionEffect ef : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(ef.getType());
        p.setFireTicks(0);
        p.setFallDistance(0f);
        if (envanter != null) {
            PlayerInventory inv = p.getInventory();
            inv.clear();
            inv.setStorageContents(Arrays.copyOfRange(envanter, 0, 36));
            inv.setArmorContents(Arrays.copyOfRange(envanter, 36, 40));
            inv.setItemInOffHand(envanter[40]);
        }
        p.setGameMode(mod);
        AttributeInstance max = p.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        double maks = max != null ? max.getValue() : 20.0;
        p.setHealth(canDoldur ? maks : Math.max(1.0, Math.min(can, maks)));
        p.setFoodLevel(canDoldur ? 20 : yemek);
        p.setSaturation(canDoldur ? 20f : doygunluk);
    }

    // ---------------- Disk ----------------

    private static File dosya(UUID id) {
        return new File(klasor, id + ".yml");
    }

    static boolean diskteVar(UUID id) {
        return dosya(id).exists();
    }

    static void sil(UUID id) {
        File f = dosya(id);
        if (f.exists() && !f.delete()) f.deleteOnExit();
    }

    void diskeYaz(UUID id) throws IOException {
        klasor.mkdirs();
        YamlConfiguration y = new YamlConfiguration();
        y.set("konum", konum);
        y.set("mod", mod.name());
        y.set("can", can);
        y.set("yemek", yemek);
        y.set("doygunluk", (double) doygunluk);
        if (envanter != null) y.set("envanter", kodla(envanter));
        y.save(dosya(id));
    }

    static Yedek diskten(UUID id) {
        File f = dosya(id);
        if (!f.exists()) return null;
        try {
            YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
            Yedek ye = new Yedek();
            ye.konum = y.getLocation("konum");
            ye.mod = GameMode.valueOf(y.getString("mod", "SURVIVAL"));
            ye.can = y.getDouble("can", 20);
            ye.yemek = y.getInt("yemek", 20);
            ye.doygunluk = (float) y.getDouble("doygunluk", 20);
            String env = y.getString("envanter");
            if (env != null) ye.envanter = coz(env);
            return ye;
        } catch (Exception e) {
            Bukkit.getLogger().warning("[GreenLemonDuello] Yedek okunamadı (" + id + "): " + e.getMessage());
            return null;
        }
    }

    private static String kodla(ItemStack[] items) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        try (BukkitObjectOutputStream out = new BukkitObjectOutputStream(bos)) {
            out.writeInt(items.length);
            for (ItemStack it : items) out.writeObject(it);
        }
        return Base64.getEncoder().encodeToString(bos.toByteArray());
    }

    private static ItemStack[] coz(String s) throws IOException, ClassNotFoundException {
        byte[] data = Base64.getDecoder().decode(s);
        try (BukkitObjectInputStream in = new BukkitObjectInputStream(new ByteArrayInputStream(data))) {
            int n = in.readInt();
            ItemStack[] items = new ItemStack[n];
            for (int i = 0; i < n; i++) items[i] = (ItemStack) in.readObject();
            return items;
        }
    }
}
