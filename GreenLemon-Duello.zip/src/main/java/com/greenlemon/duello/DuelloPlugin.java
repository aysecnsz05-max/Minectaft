package com.greenlemon.duello;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class DuelloPlugin extends JavaPlugin {

    private Arenalar arenalar;
    private Kitler kitler;
    private Istatistik istatistik;
    private MacYonetici yonetici;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        Yedek.klasor = new File(getDataFolder(), "yedek");
        arenalar = new Arenalar(this);
        arenalar.yukle();
        kitler = new Kitler(this);
        kitler.yukle();
        istatistik = new Istatistik(this);
        istatistik.yukle();
        yonetici = new MacYonetici(this);

        getServer().getPluginManager().registerEvents(new Dinleyici(this), this);
        Komutlar komutlar = new Komutlar(this);
        PluginCommand c = getCommand("duello");
        if (c != null) {
            c.setExecutor(komutlar);
            c.setTabCompleter(komutlar);
        }
        yonetici.baslat();
        getLogger().info(arenalar.tum().size() + " arena, " + kitler.sayi() + " kit yüklendi.");
    }

    @Override
    public void onDisable() {
        if (yonetici != null) yonetici.kapat();
        if (istatistik != null) istatistik.kaydet();
        if (arenalar != null) arenalar.kaydet();
    }

    void yenidenYukle() {
        reloadConfig();
        kitler.yukle();
    }

    Arenalar arenalar() {
        return arenalar;
    }

    Kitler kitler() {
        return kitler;
    }

    Istatistik istatistik() {
        return istatistik;
    }

    MacYonetici yonetici() {
        return yonetici;
    }

    // ---------------- Yardımcılar ----------------

    Location sunucuSpawn() {
        return getServer().getWorlds().get(0).getSpawnLocation();
    }

    String m(String anahtar, String... cift) {
        return Yazi.renk(doldur(getConfig().getString("mesajlar." + anahtar, "&cMesaj bulunamadı: " + anahtar), cift));
    }

    List<String> mListe(String anahtar) {
        List<String> sonuc = new ArrayList<>();
        for (String t : getConfig().getStringList("mesajlar." + anahtar)) sonuc.add(Yazi.renk(doldur(t)));
        return sonuc;
    }

    private String doldur(String t, String... cift) {
        t = t.replace("{prefix}", getConfig().getString("mesajlar.prefix", ""));
        for (int i = 0; i + 1 < cift.length; i += 2) t = t.replace(cift[i], cift[i + 1]);
        return t;
    }

    void ses(Player p, String anahtar, float perde) {
        try {
            Sound s = Sound.valueOf(getConfig().getString("sesler." + anahtar, "").toUpperCase(Locale.ROOT));
            p.playSound(p.getLocation(), s, 1.0f, perde);
        } catch (IllegalArgumentException ignored) {
            // ses adı geçersiz veya boş
        }
    }

    /** Menü/eşya yardımcısı: renk kodlu ad ve lore ile eşya. */
    static ItemStack esya(Material m, String ad, List<String> lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.setDisplayName(Yazi.renk(ad));
        List<String> l = new ArrayList<>();
        for (String s : lore) l.add(Yazi.renk(s));
        meta.setLore(l);
        it.setItemMeta(meta);
        return it;
    }
}
