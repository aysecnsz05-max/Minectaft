package com.greenlemon.duello;

import org.bukkit.boss.BossBar;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Süren bir düello. */
final class Mac {
    enum Faz { GERI_SAYIM, DOVUS, ROUND_ARASI, TOPLAMA, BITTI }

    final Arena arena;
    final UUID a;
    final UUID b;
    final Ayar ayar;
    final Map<UUID, Yedek> yedek = new HashMap<>();
    final Set<UUID> izleyiciler = new HashSet<>();

    int skorA;
    int skorB;
    int round;
    Faz faz = Faz.GERI_SAYIM;
    int sayac;
    long roundBitis;
    long toplamaBitis;
    boolean roundAktif;
    UUID beklenenOlu;     // gerçek ölümle bitecek maçta ölen oyuncu
    BossBar bar;

    Mac(Arena arena, UUID a, UUID b, Ayar ayar) {
        this.arena = arena;
        this.a = a;
        this.b = b;
        this.ayar = ayar;
    }

    UUID rakip(UUID u) {
        if (u.equals(a)) return b;
        if (u.equals(b)) return a;
        return null;
    }

    int skor(UUID u) {
        return u.equals(a) ? skorA : skorB;
    }

    void skorArtir(UUID u) {
        if (u.equals(a)) skorA++;
        else skorB++;
    }

    String skorYazi() {
        return skorA + "-" + skorB;
    }

    boolean aktifFaz() {
        return faz == Faz.GERI_SAYIM || faz == Faz.DOVUS || faz == Faz.ROUND_ARASI;
    }
}
