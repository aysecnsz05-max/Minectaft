package com.greenlemon.duello;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.hover.content.Text;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.command.Command;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.scheduler.BukkitTask;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/** Davetler, sıra, maç akışı, round'lar, ölüm yakalama, izleme. Sadece ana thread. */
final class MacYonetici {

    static final class Davet {
        final UUID gonderen;
        final UUID hedef;
        final Ayar ayar;
        final long bitis;

        Davet(UUID gonderen, UUID hedef, Ayar ayar, long bitis) {
            this.gonderen = gonderen;
            this.hedef = hedef;
            this.ayar = ayar;
            this.bitis = bitis;
        }
    }

    private final DuelloPlugin plugin;
    private final Set<Mac> maclar = new LinkedHashSet<>();
    private final Map<UUID, Mac> oyuncuMac = new HashMap<>();
    private final Map<UUID, Mac> izleyenMac = new HashMap<>();
    private final Map<UUID, Yedek> izleyenYedek = new HashMap<>();
    private final Map<UUID, Davet> gelen = new HashMap<>();
    private final Map<UUID, Davet> giden = new HashMap<>();
    private final Map<String, Deque<UUID>> kuyruk = new LinkedHashMap<>();
    private final Random rastgele = new Random();
    private BukkitTask ticker;

    MacYonetici(DuelloPlugin plugin) {
        this.plugin = plugin;
    }

    void baslat() {
        ticker = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 20L, 20L);
    }

    void kapat() {
        if (ticker != null) ticker.cancel();
        for (Mac m : new ArrayList<>(maclar)) macKapat(m);
        for (UUID id : new ArrayList<>(izleyenMac.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) izlemeyiBirak(p);
        }
    }

    // ================= Sorgular =================

    Collection<Mac> maclar() {
        return new ArrayList<>(maclar);
    }

    Mac macOf(UUID id) {
        return oyuncuMac.get(id);
    }

    boolean katilimci(Player p) {
        return oyuncuMac.containsKey(p.getUniqueId());
    }

    boolean izleyici(Player p) {
        return izleyenMac.containsKey(p.getUniqueId());
    }

    boolean musait(UUID id) {
        return !oyuncuMac.containsKey(id) && !izleyenMac.containsKey(id) && kuyrukKit(id) == null;
    }

    String kuyrukKit(UUID id) {
        for (Map.Entry<String, Deque<UUID>> e : kuyruk.entrySet()) if (e.getValue().contains(id)) return e.getKey();
        return null;
    }

    private void kuyrukCikar(UUID id) {
        for (Deque<UUID> q : kuyruk.values()) q.remove(id);
    }

    Davet gelenDavet(UUID hedef) {
        Davet d = gelen.get(hedef);
        if (d != null && System.currentTimeMillis() > d.bitis) {
            gelen.remove(hedef);
            giden.remove(d.gonderen);
            return null;
        }
        return d;
    }

    private static Player on(UUID id) {
        return id == null ? null : Bukkit.getPlayer(id);
    }

    private static String ad(UUID id) {
        Player p = Bukkit.getPlayer(id);
        if (p != null) return p.getName();
        String n = Bukkit.getOfflinePlayer(id).getName();
        return n == null ? "?" : n;
    }

    String kitAdi(String kit) {
        if (Ayar.KENDI.equals(kit)) return plugin.getConfig().getString("kendi-esyalar.ad", "&aKendi Eşyalarım");
        Kit k = plugin.kitler().al(kit);
        return k == null ? kit : k.ad;
    }

    // ================= Davetler =================

    boolean davetGonder(Player g, Player h, Ayar ayar) {
        UUID gid = g.getUniqueId();
        UUID hid = h.getUniqueId();
        if (gid.equals(hid)) {
            g.sendMessage(plugin.m("kendine"));
            return false;
        }
        if (!musait(gid)) {
            g.sendMessage(plugin.m("sen-mesgulsun"));
            return false;
        }
        if (!musait(hid)) {
            g.sendMessage(plugin.m("oyuncu-mesgul", "{oyuncu}", h.getName()));
            return false;
        }
        if (plugin.istatistik().davetKapali(hid)) {
            g.sendMessage(plugin.m("davet-kapali", "{oyuncu}", h.getName()));
            return false;
        }
        if (gelenDavet(hid) != null) {
            g.sendMessage(plugin.m("zaten-davet-var", "{oyuncu}", h.getName()));
            return false;
        }
        ayar.duzelt();
        if (ayar.kitModu() && plugin.kitler().al(ayar.kit) == null) {
            g.sendMessage(plugin.m("kit-yok"));
            return false;
        }

        Davet eski = giden.remove(gid);
        if (eski != null) gelen.remove(eski.hedef);
        int sn = plugin.getConfig().getInt("davet-saniye", 30);
        Davet d = new Davet(gid, hid, ayar.kopya(), System.currentTimeMillis() + sn * 1000L);
        gelen.put(hid, d);
        giden.put(gid, d);
        g.sendMessage(plugin.m("davet-gonderildi", "{oyuncu}", h.getName(), "{saniye}", String.valueOf(sn)));
        davetMesaji(h, g, d);
        return true;
    }

    private void davetMesaji(Player h, Player g, Davet d) {
        Ayar ay = d.ayar;
        h.sendMessage(plugin.m("davet-baslik"));
        h.sendMessage(plugin.m("davet-gonderen", "{oyuncu}", g.getName()));
        h.sendMessage(plugin.m("davet-satir-kit", "{kit}", kitAdi(ay.kit)));
        h.sendMessage(plugin.m("davet-satir-arena", "{arena}", ay.arena == null ? "Rastgele" : ay.arena));
        h.sendMessage(plugin.m("davet-satir-round", "{round}", String.valueOf(ay.round),
                "{gerekli}", String.valueOf(ay.gerekli())));
        h.sendMessage(plugin.m(ay.dusme ? "davet-satir-esya-duser" : "davet-satir-esya-dusmez"));

        TextComponent satir = new TextComponent();
        if (ay.dusme) {
            satir.addExtra(buton("&e&l[DAVETİ İNCELE]", "/duello gelen", "Menüyü aç"));
            h.spigot().sendMessage(satir);
            h.sendMessage(plugin.m("davet-menuden-kabul"));
        } else {
            satir.addExtra(buton("&a&l[KABUL ET]", "/duello kabul", "Düelloyu kabul et"));
            satir.addExtra(new TextComponent("  "));
            satir.addExtra(buton("&c&l[REDDET]", "/duello red", "Daveti reddet"));
            satir.addExtra(new TextComponent("  "));
            satir.addExtra(buton("&e&l[İNCELE]", "/duello gelen", "Menüyü aç"));
            h.spigot().sendMessage(satir);
        }
        plugin.ses(h, "davet", 1f);
    }

    private TextComponent buton(String yazi, String komut, String ipucu) {
        TextComponent t = new TextComponent(TextComponent.fromLegacyText(Yazi.renk(yazi)));
        t.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, komut));
        t.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text(Yazi.renk("&7" + ipucu))));
        return t;
    }

    void davetKabul(Player h, boolean menuden) {
        Davet d = gelenDavet(h.getUniqueId());
        if (d == null) {
            h.sendMessage(plugin.m("davet-yok"));
            return;
        }
        if (d.ayar.dusme && !menuden) {
            h.sendMessage(plugin.m("davet-menuden-kabul"));
            return;
        }
        gelen.remove(h.getUniqueId());
        giden.remove(d.gonderen);
        Player g = on(d.gonderen);
        if (g == null) {
            h.sendMessage(plugin.m("davet-yok"));
            return;
        }
        if (!musait(g.getUniqueId()) || !musait(h.getUniqueId())) {
            h.sendMessage(plugin.m("oyuncu-mesgul", "{oyuncu}", g.getName()));
            return;
        }
        Arena a = arenaBul(d.ayar);
        if (a == null) {
            String anahtar = d.ayar.arena != null && plugin.arenalar().al(d.ayar.arena) != null
                    ? "arena-secili-dolu" : "arena-yok";
            g.sendMessage(plugin.m(anahtar));
            h.sendMessage(plugin.m(anahtar));
            return;
        }
        macBaslat(g, h, d.ayar, a);
    }

    void davetReddet(Player h) {
        Davet d = gelenDavet(h.getUniqueId());
        if (d == null) {
            h.sendMessage(plugin.m("davet-yok"));
            return;
        }
        gelen.remove(h.getUniqueId());
        giden.remove(d.gonderen);
        h.sendMessage(plugin.m("davet-red-hedef"));
        Player g = on(d.gonderen);
        if (g != null) g.sendMessage(plugin.m("davet-red-gonderen", "{oyuncu}", h.getName()));
    }

    private void davetleriIptalEt(UUID id) {
        Davet a = gelen.remove(id);
        if (a != null) {
            giden.remove(a.gonderen);
            Player g = on(a.gonderen);
            if (g != null) g.sendMessage(plugin.m("davet-iptal", "{oyuncu}", ad(id)));
        }
        Davet b = giden.remove(id);
        if (b != null) {
            gelen.remove(b.hedef);
            Player h = on(b.hedef);
            if (h != null) h.sendMessage(plugin.m("davet-iptal", "{oyuncu}", ad(id)));
        }
    }

    private Arena arenaBul(Ayar ayar) {
        if (ayar.arena != null) {
            Arena a = plugin.arenalar().al(ayar.arena);
            return a != null && a.bos() ? a : null;
        }
        return bosArena();
    }

    private Arena bosArena() {
        List<Arena> bos = new ArrayList<>();
        for (Arena a : plugin.arenalar().tum()) if (a.bos()) bos.add(a);
        return bos.isEmpty() ? null : bos.get(rastgele.nextInt(bos.size()));
    }

    // ================= Dereceli sıra =================

    void kuyrugaGir(Player p, String kitId) {
        if (Ayar.KENDI.equalsIgnoreCase(kitId)) {
            p.sendMessage(plugin.m("kuyruk-kendi"));
            return;
        }
        Kit k = plugin.kitler().al(kitId);
        if (k == null) {
            p.sendMessage(plugin.m("kit-yok"));
            return;
        }
        if (!musait(p.getUniqueId())) {
            p.sendMessage(plugin.m("sen-mesgulsun"));
            return;
        }
        kuyruk.computeIfAbsent(k.id, x -> new ArrayDeque<>()).addLast(p.getUniqueId());
        p.sendMessage(plugin.m("kuyruga-girdi", "{kit}", k.ad));
        eslestir();
    }

    /** Sıradan veya izlemeden çıkar. */
    void cik(Player p) {
        UUID id = p.getUniqueId();
        if (kuyrukKit(id) != null) {
            kuyrukCikar(id);
            p.sendMessage(plugin.m("kuyruktan-cikti"));
        } else if (izleyici(p)) {
            izlemeyiBirak(p);
        } else {
            p.sendMessage(plugin.m("kuyrukta-degil"));
        }
    }

    private void eslestir() {
        for (String kit : new ArrayList<>(kuyruk.keySet())) {
            Deque<UUID> q = kuyruk.get(kit);
            if (q == null) continue;
            q.removeIf(u -> Bukkit.getPlayer(u) == null);
            while (q.size() >= 2) {
                Arena a = bosArena();
                if (a == null) break;
                UUID u1 = q.pollFirst();
                UUID u2 = q.pollFirst();
                Player p1 = on(u1);
                Player p2 = on(u2);
                if (p1 == null || p2 == null) continue;
                Ayar ay = new Ayar();
                ay.kit = kit;
                ay.dereceli = true;
                ay.round = plugin.getConfig().getInt("sira.round", 1);
                macBaslat(p1, p2, ay, a);
            }
        }
    }

    // ================= Maç başlatma =================

    private void macBaslat(Player p1, Player p2, Ayar ayar, Arena arena) {
        ayar.duzelt();
        boolean kit = ayar.kitModu();

        // Önce yedekler diske yazılır; kit modunda yazılamazsa maç hiç başlamaz (eşya kaybı olmasın)
        Yedek y1 = Yedek.al(p1, kit);
        Yedek y2 = Yedek.al(p2, kit);
        try {
            y1.diskeYaz(p1.getUniqueId());
            y2.diskeYaz(p2.getUniqueId());
        } catch (IOException e) {
            plugin.getLogger().warning("Yedek yazılamadı: " + e.getMessage());
            if (kit) {
                Yedek.sil(p1.getUniqueId());
                Yedek.sil(p2.getUniqueId());
                p1.sendMessage(plugin.m("yedek-hata"));
                p2.sendMessage(plugin.m("yedek-hata"));
                return;
            }
        }

        Mac m = new Mac(arena, p1.getUniqueId(), p2.getUniqueId(), ayar);
        m.yedek.put(p1.getUniqueId(), y1);
        m.yedek.put(p2.getUniqueId(), y2);
        arena.mac = m;
        maclar.add(m);
        for (Player p : new Player[]{p1, p2}) {
            kuyrukCikar(p.getUniqueId());
            davetleriIptalEt(p.getUniqueId());
            oyuncuMac.put(p.getUniqueId(), m);
        }
        m.bar = Bukkit.createBossBar("", BarColor.RED, BarStyle.SOLID);
        m.bar.addPlayer(p1);
        m.bar.addPlayer(p2);
        p1.sendMessage(plugin.m("mac-basladi", "{rakip}", p2.getName()));
        p2.sendMessage(plugin.m("mac-basladi", "{rakip}", p1.getName()));
        roundHazirla(m, plugin.getConfig().getInt("sureler.geri-sayim", 5));
    }

    private void saglikliYap(Player p) {
        p.setGameMode(GameMode.SURVIVAL);
        for (PotionEffect ef : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(ef.getType());
        AttributeInstance mx = p.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        p.setHealth(mx != null ? mx.getValue() : 20.0);
        p.setFoodLevel(20);
        p.setSaturation(20f);
        p.setFireTicks(0);
        p.setFallDistance(0f);
    }

    private void roundHazirla(Mac m, int sayacSn) {
        m.round++;
        m.roundAktif = false;
        m.beklenenOlu = null;
        Player a = on(m.a);
        Player b = on(m.b);
        if (a == null || b == null) return;

        Kit kit = m.ayar.kitModu() ? plugin.kitler().al(m.ayar.kit) : null;
        for (Player p : new Player[]{a, b}) {
            saglikliYap(p);
            if (kit != null) kit.ver(p);
        }
        Location l1 = m.arena.spawn1.al();
        Location l2 = m.arena.spawn2.al();
        if (l1 != null) a.teleport(l1);
        if (l2 != null) b.teleport(l2);
        m.faz = Mac.Faz.GERI_SAYIM;
        m.sayac = sayacSn;
        barGuncelle(m);
    }

    // ================= Tick =================

    private void tick() {
        long simdi = System.currentTimeMillis();

        for (Mac m : new ArrayList<>(maclar)) {
            switch (m.faz) {
                case GERI_SAYIM -> {
                    if (m.sayac > 0) {
                        String sayi = String.valueOf(m.sayac);
                        for (Player p : oyuncular(m)) {
                            p.sendTitle(plugin.m("geri-sayim-baslik", "{sayi}", sayi), plugin.m("geri-sayim-alt"), 0, 25, 0);
                            plugin.ses(p, "geri-sayim", 1f);
                        }
                        m.sayac--;
                    } else {
                        m.faz = Mac.Faz.DOVUS;
                        m.roundAktif = true;
                        m.roundBitis = simdi + plugin.getConfig().getLong("sureler.round-saniye", 300) * 1000L;
                        for (Player p : oyuncular(m)) {
                            p.sendTitle(plugin.m("dovus-baslik"), plugin.m("dovus-alt", "{round}", String.valueOf(m.round)), 0, 30, 10);
                            plugin.ses(p, "basla", 1f);
                        }
                    }
                    barGuncelle(m);
                }
                case DOVUS -> {
                    barGuncelle(m);
                    sinirKontrol(m);
                    if (simdi >= m.roundBitis) roundZamanAsimi(m);
                }
                case ROUND_ARASI -> {
                    if (m.sayac > 0) m.sayac--;
                    else roundHazirla(m, plugin.getConfig().getInt("sureler.round-arasi-geri-sayim", 3));
                }
                case TOPLAMA -> {
                    barGuncelle(m);
                    if (simdi >= m.toplamaBitis) macKapat(m);
                }
                case BITTI -> {
                    if (m.sayac > 0) m.sayac--;
                    else macKapat(m);
                }
            }
        }

        // Süresi dolan davetler
        for (Davet d : new ArrayList<>(giden.values())) {
            if (simdi > d.bitis) {
                giden.remove(d.gonderen);
                gelen.remove(d.hedef);
                Player g = on(d.gonderen);
                if (g != null) g.sendMessage(plugin.m("davet-sure-doldu", "{oyuncu}", ad(d.hedef)));
            }
        }
        eslestir();
    }

    private List<Player> oyuncular(Mac m) {
        List<Player> l = new ArrayList<>();
        for (UUID id : new UUID[]{m.a, m.b}) {
            Player p = on(id);
            if (p != null && oyuncuMac.get(id) == m) l.add(p);
        }
        return l;
    }

    private void sinirKontrol(Mac m) {
        for (Player p : oyuncular(m)) {
            if (m.arena.icerde(p.getLocation())) continue;
            Arena.Konum k = p.getUniqueId().equals(m.a) ? m.arena.spawn1 : m.arena.spawn2;
            Location l = k == null ? null : k.al();
            if (l != null) p.teleport(l);
        }
    }

    private void barGuncelle(Mac m) {
        if (m.bar == null) return;
        String skor = "&c" + ad(m.a) + " &f" + m.skorA + " &8- &f" + m.skorB + " &9" + ad(m.b);
        String baslik;
        double ilerleme = 1.0;
        BarColor renk = BarColor.RED;
        switch (m.faz) {
            case GERI_SAYIM -> {
                baslik = skor + " &8| &eBaşlıyor: &f" + m.sayac;
                renk = BarColor.YELLOW;
            }
            case DOVUS -> {
                long toplam = plugin.getConfig().getLong("sureler.round-saniye", 300);
                long kalan = Math.max(0, (m.roundBitis - System.currentTimeMillis() + 999) / 1000);
                baslik = skor + " &8| &7Round &f" + m.round + " &8| &e" + String.format("%d:%02d", kalan / 60, kalan % 60);
                ilerleme = toplam <= 0 ? 1.0 : (double) kalan / toplam;
            }
            case ROUND_ARASI -> {
                baslik = skor + " &8| &7Yeni round hazırlanıyor...";
                renk = BarColor.YELLOW;
            }
            case TOPLAMA -> {
                long toplam = plugin.getConfig().getLong("sureler.esya-toplama", 15);
                long kalan = Math.max(0, (m.toplamaBitis - System.currentTimeMillis() + 999) / 1000);
                baslik = "&aEşyaları topla! &f" + kalan + " sn";
                ilerleme = toplam <= 0 ? 0 : (double) kalan / toplam;
                renk = BarColor.GREEN;
            }
            default -> {
                baslik = skor + " &8| &aMaç bitti";
                renk = BarColor.GREEN;
            }
        }
        m.bar.setTitle(Yazi.renk(baslik));
        m.bar.setColor(renk);
        m.bar.setProgress(Math.max(0.0, Math.min(1.0, ilerleme)));
    }

    // ================= Round / maç sonu =================

    private void roundZamanAsimi(Mac m) {
        Player a = on(m.a);
        Player b = on(m.b);
        if (a == null || b == null) return;
        m.roundAktif = false;
        double ha = a.getHealth();
        double hb = b.getHealth();
        if (Math.abs(ha - hb) < 0.01) {
            for (Player p : oyuncular(m)) p.sendMessage(plugin.m("round-beraber"));
            m.round--; // aynı round tekrar
            roundHazirla(m, plugin.getConfig().getInt("sureler.round-arasi-geri-sayim", 3));
            return;
        }
        for (Player p : oyuncular(m)) p.sendMessage(plugin.m("round-zaman"));
        roundBitir(m, ha > hb ? m.a : m.b);
    }

    void roundBitir(Mac m, UUID kazanan) {
        if (!maclar.contains(m) || m.faz != Mac.Faz.DOVUS) return;
        UUID kaybeden = m.rakip(kazanan);
        m.roundAktif = false;
        m.skorArtir(kazanan);
        if (m.skor(kazanan) >= m.ayar.gerekli()) {
            macBitir(m, kazanan, kaybeden, false);
            return;
        }
        String skor = m.skorYazi();
        Player kz = on(kazanan);
        Player kb = on(kaybeden);
        String r = String.valueOf(m.round);
        if (kz != null) {
            kz.sendTitle(plugin.m("round-kazandin", "{round}", r), plugin.m("round-alt", "{skor}", skor), 0, 40, 10);
            plugin.ses(kz, "round-kazan", 1f);
        }
        if (kb != null) {
            kb.sendTitle(plugin.m("round-kaybettin", "{round}", r), plugin.m("round-alt", "{skor}", skor), 0, 40, 10);
            plugin.ses(kb, "round-kaybet", 1f);
        }
        m.faz = Mac.Faz.ROUND_ARASI;
        m.sayac = plugin.getConfig().getInt("sureler.round-arasi-bekleme", 3);
        barGuncelle(m);
    }

    private void macBitir(Mac m, UUID kazanan, UUID kaybeden, boolean gercekOlum) {
        if (!maclar.contains(m) || m.faz == Mac.Faz.TOPLAMA || m.faz == Mac.Faz.BITTI) return;
        m.roundAktif = false;
        String kzAd = ad(kazanan);
        String kbAd = ad(kaybeden);

        plugin.istatistik().kazanma(kazanan, kzAd);
        plugin.istatistik().kayip(kaybeden, kbAd);
        int elo = 0;
        if (m.ayar.dereceli) elo = plugin.istatistik().eloGuncelle(kazanan, kaybeden);

        String skor = m.skorYazi();
        Player kz = on(kazanan);
        Player kb = on(kaybeden);
        if (kz != null) {
            String eloYazi = m.ayar.dereceli ? plugin.m("elo-artti", "{deger}", String.valueOf(elo)) : "";
            kz.sendTitle(plugin.m("mac-kazandin-baslik"), plugin.m("mac-sonuc-alt", "{skor}", skor, "{elo}", eloYazi), 5, 60, 15);
            plugin.ses(kz, "round-kazan", 1f);
        }
        if (kb != null) {
            String eloYazi = m.ayar.dereceli ? plugin.m("elo-azaldi", "{deger}", String.valueOf(elo)) : "";
            kb.sendTitle(plugin.m("mac-kaybettin-baslik"), plugin.m("mac-sonuc-alt", "{skor}", skor, "{elo}", eloYazi), 5, 60, 15);
            plugin.ses(kb, "round-kaybet", 1f);
        }
        if (plugin.getConfig().getBoolean("duyuru.kazanan", false)) {
            Bukkit.broadcastMessage(plugin.m("duyuru-kazanan", "{kazanan}", kzAd, "{kaybeden}", kbAd, "{skor}", skor));
        }

        boolean toplama = gercekOlum && m.ayar.dusme && !m.ayar.kitModu();
        if (toplama) {
            // Kaybeden eski yerine döner; kazanan eşyaları toplar
            Player loser = on(kaybeden);
            if (loser != null && oyuncuMac.get(kaybeden) == m) geriYukle(m, loser);
            oyuncuMac.remove(kaybeden);
            long sn = plugin.getConfig().getLong("sureler.esya-toplama", 15);
            m.faz = Mac.Faz.TOPLAMA;
            m.toplamaBitis = System.currentTimeMillis() + sn * 1000L;
            if (kz != null) kz.sendMessage(plugin.m("mac-kazandin-esya", "{saniye}", String.valueOf(sn)));
        } else {
            m.faz = Mac.Faz.BITTI;
            m.sayac = plugin.getConfig().getInt("sureler.bitis-gecikme", 3);
        }
        barGuncelle(m);
    }

    /** Maçı bitirir: herkesi eski durumuna ve yerine döndürür, arenayı boşaltır. */
    void macKapat(Mac m) {
        if (!maclar.remove(m)) return;
        for (UUID id : new UUID[]{m.a, m.b}) {
            if (oyuncuMac.get(id) != m) continue;
            Player p = on(id);
            if (p != null) geriYukle(m, p);
            oyuncuMac.remove(id);
        }
        for (UUID s : new ArrayList<>(m.izleyiciler)) {
            Player p = on(s);
            if (p != null) izlemeyiBirak(p);
            else {
                izleyenMac.remove(s);
                izleyenYedek.remove(s);
            }
        }
        if (m.bar != null) {
            m.bar.removeAll();
            m.bar = null;
        }
        m.arena.mac = null;
    }

    /** Yetkili iptali: istatistik işlenmez. */
    void macIptal(Mac m) {
        for (Player p : oyuncular(m)) p.sendMessage(plugin.m("iptal-edildi"));
        m.roundAktif = false;
        macKapat(m);
    }

    private void geriYukle(Mac m, Player p) {
        UUID id = p.getUniqueId();
        Yedek y = m.yedek.remove(id);
        if (m.bar != null) m.bar.removePlayer(p);
        if (y == null || p.isDead()) return;
        y.uygula(p, plugin.getConfig().getBoolean("bitis.iyilestir", true));
        p.teleport(donusKonumu(y));
        Yedek.sil(id);
    }

    private Location donusKonumu(Yedek y) {
        boolean spawn = "SPAWN".equalsIgnoreCase(plugin.getConfig().getString("bitis.donus", "ONCEKI_KONUM"));
        if (spawn || y == null || y.konum == null || y.konum.getWorld() == null) return plugin.sunucuSpawn();
        return y.konum;
    }

    // ================= Olaylardan gelen işler =================

    /** Hasar: maç dışı vuruşları engeller, öldürücü vuruşu round kaybına çevirir. */
    void hasarIsle(EntityDamageEvent e, Player kurban, Player saldirgan) {
        UUID id = kurban.getUniqueId();
        Mac m = oyuncuMac.get(id);
        if (m == null) {
            if (saldirgan != null && oyuncuMac.containsKey(saldirgan.getUniqueId())) e.setCancelled(true);
            return;
        }

        if (!m.roundAktif) {
            e.setCancelled(true);
            if (e.getCause() == EntityDamageEvent.DamageCause.VOID) {
                Arena.Konum k = id.equals(m.a) ? m.arena.spawn1 : m.arena.spawn2;
                Location l = k == null ? null : k.al();
                if (l != null) Bukkit.getScheduler().runTask(plugin, () -> kurban.teleport(l));
            }
            return;
        }
        UUID rakip = m.rakip(id);
        if (saldirgan != null && !saldirgan.equals(kurban) && !saldirgan.getUniqueId().equals(rakip)) {
            e.setCancelled(true);
            return;
        }

        // Öldürücü vuruş mu?
        if (kurban.getHealth() - e.getFinalDamage() > 0) return;
        if (totemVar(kurban)) return; // totem vanilla'da çalışsın

        boolean karar = m.skor(rakip) + 1 >= m.ayar.gerekli();
        boolean esyaDusur = m.ayar.dusme && !m.ayar.kitModu();
        m.roundAktif = false;
        if (karar && esyaDusur) {
            m.beklenenOlu = id; // gerçek ölüm: eşyalar düşecek
            return;
        }
        e.setCancelled(true); // ölüm yok: round kaybı
        Bukkit.getScheduler().runTask(plugin, () -> roundBitir(m, rakip));
    }

    private static boolean totemVar(Player p) {
        return p.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING
                || p.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    /** Gerçek ölüm (eşya düşen karar vuruşu ya da beklenmedik ölüm). */
    void olumIsle(Player kurban, PlayerDeathEvent e) {
        UUID id = kurban.getUniqueId();
        Mac m = oyuncuMac.get(id);
        if (m == null) return;
        boolean esyaDusuyor = m.ayar.dusme && !m.ayar.kitModu();
        e.setKeepInventory(!esyaDusuyor);
        if (!esyaDusuyor) e.getDrops().clear();
        e.setKeepLevel(true);
        e.setDroppedExp(0);
        e.setDeathMessage(null);
        m.roundAktif = false;
        m.beklenenOlu = id;
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (kurban.isOnline() && kurban.isDead()) kurban.spigot().respawn();
        });
    }

    /** Yeniden doğma konumu; maça bağlı ölümse eski konum. Değilse null. */
    Location respawnKonumu(Player p) {
        UUID id = p.getUniqueId();
        Mac m = oyuncuMac.get(id);
        if (m == null || !id.equals(m.beklenenOlu)) return null;
        Location hedef = donusKonumu(m.yedek.get(id));
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (maclar.contains(m) && m.aktifFaz()) macBitir(m, m.rakip(id), id, true);
        });
        return hedef;
    }

    /** Oyuncu çıktı: sıradan, davetlerden, izlemeden, maçtan temizlenir. */
    void oyuncuAyrildi(Player p) {
        UUID id = p.getUniqueId();
        kuyrukCikar(id);
        davetleriIptalEt(id);
        if (izleyici(p)) izlemeyiBirak(p);
        Mac m = oyuncuMac.get(id);
        if (m == null) return;

        geriYukle(m, p); // eşyalar ve konum çıkmadan önce geri verilir
        oyuncuMac.remove(id);
        UUID r = m.rakip(id);
        if (m.aktifFaz()) {
            Player rp = on(r);
            if (rp != null) rp.sendMessage(plugin.m("rakip-ayrildi"));
            macBitir(m, r, id, false);
        } else if (oyuncuMac.get(r) != m) {
            macKapat(m);
        }
    }

    /** Çökme/yeniden başlatma sonrası: diskte yedeği kalan oyuncuya eşyalarını/konumunu geri ver. */
    void oyuncuGirdi(Player p) {
        UUID id = p.getUniqueId();
        if (oyuncuMac.containsKey(id) || izleyenMac.containsKey(id) || !Yedek.diskteVar(id)) return;
        Yedek y = Yedek.diskten(id);
        if (y == null) return;
        y.uygula(p, true);
        p.teleport(donusKonumu(y));
        Yedek.sil(id);
        p.sendMessage(plugin.m("yedek-geri-verildi"));
    }

    // ================= İzleme =================

    void izle(Player p, Mac m) {
        UUID id = p.getUniqueId();
        if (!musait(id)) {
            p.sendMessage(plugin.m("sen-mesgulsun"));
            return;
        }
        if (!maclar.contains(m)) {
            p.sendMessage(plugin.m("izle-yok"));
            return;
        }
        Yedek y = Yedek.al(p, false);
        izleyenYedek.put(id, y);
        izleyenMac.put(id, m);
        m.izleyiciler.add(id);
        try {
            y.diskeYaz(id);
        } catch (IOException ex) {
            plugin.getLogger().warning("İzleyici yedeği yazılamadı: " + ex.getMessage());
        }
        Location l = m.arena.izle != null ? m.arena.izle.al() : null;
        if (l == null) l = m.arena.spawn1.al();
        p.setGameMode(GameMode.SPECTATOR);
        if (l != null) p.teleport(l);
        if (m.bar != null) m.bar.addPlayer(p);
        p.sendMessage(plugin.m("izle-basladi"));
    }

    void izlemeyiBirak(Player p) {
        UUID id = p.getUniqueId();
        Mac m = izleyenMac.remove(id);
        Yedek y = izleyenYedek.remove(id);
        if (m != null) {
            m.izleyiciler.remove(id);
            if (m.bar != null) m.bar.removePlayer(p);
        }
        if (y != null) {
            y.uygula(p, false);
            p.teleport(donusKonumu(y));
            Yedek.sil(id);
            p.sendMessage(plugin.m("izle-bitti"));
        }
    }

    // ================= Komut engeli =================

    boolean komutEngelli(Player p) {
        return oyuncuMac.containsKey(p.getUniqueId()) || izleyenMac.containsKey(p.getUniqueId());
    }

    boolean komutYasakMi(String ham) {
        String c = ham.startsWith("/") ? ham.substring(1) : ham;
        c = c.strip().toLowerCase(Locale.ROOT);
        if (c.isEmpty()) return false;
        String etiket = c.split("\\s+")[0];
        int i = etiket.indexOf(':');
        if (i >= 0) etiket = etiket.substring(i + 1);
        if (etiket.equals("duello") || etiket.equals("duel") || etiket.equals("1v1duel")) return false;

        Set<String> adaylar = new HashSet<>();
        adaylar.add(etiket);
        try {
            Command cmd = Bukkit.getCommandMap().getCommand(etiket);
            if (cmd != null) {
                adaylar.add(cmd.getName().toLowerCase(Locale.ROOT));
                for (String al : cmd.getAliases()) adaylar.add(al.toLowerCase(Locale.ROOT));
            }
        } catch (Throwable ignored) {
            // komut haritasına erişilemezse sadece yazılana bak
        }
        boolean beyaz = "BEYAZ_LISTE".equalsIgnoreCase(plugin.getConfig().getString("komut-modu", "KARA_LISTE"));
        List<String> liste = new ArrayList<>();
        for (String s : plugin.getConfig().getStringList(beyaz ? "izinli-komutlar" : "yasakli-komutlar")) {
            liste.add(s.toLowerCase(Locale.ROOT));
        }
        boolean eslesti = false;
        for (String a : adaylar) if (liste.contains(a)) eslesti = true;
        return beyaz ? !eslesti : eslesti;
    }
}
